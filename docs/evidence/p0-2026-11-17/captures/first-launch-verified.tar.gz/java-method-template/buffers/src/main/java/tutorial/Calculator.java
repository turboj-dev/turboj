package tutorial;

public class Calculator {

    public int add(int i, int j) {
        return 0;
    }
    
}
