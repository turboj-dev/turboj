package tutorial;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;
class CalculatorTest {
    @Test void testCalculatorAddition() {
        assertEquals(42, new Calculator().add(20, 22));
    }
}
