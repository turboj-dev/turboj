package mini.prices

import io.ktor.http.ContentType
import io.ktor.http.HttpStatusCode
import io.ktor.server.application.Application
import io.ktor.server.application.ApplicationCall
import io.ktor.server.engine.embeddedServer
import io.ktor.server.netty.Netty
import io.ktor.server.response.respondText
import io.ktor.server.routing.get
import io.ktor.server.routing.routing
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import java.nio.file.Files
import java.nio.file.Path

fun main() {
    val pool = database()
    val prices = Prices(pool, required("BINANCE_API_BASE"))
    Runtime.getRuntime().addShutdownHook(Thread { pool.close() })
    embeddedServer(Netty, port = (System.getenv("PORT") ?: "3001").toInt(), host = "0.0.0.0") { routes(prices) }.start(wait = true)
}

fun Application.routes(prices: Prices) {
    routing {
        get("/health") { call.headers(); call.respondText("{\"status\":\"ok\"}", ContentType.Application.Json) }
        get("/api-docs/openapi.json") { call.headers(); call.respondText(Files.readString(Path.of(required("OPENAPI_PATH"))), ContentType.Application.Json) }
        get("/btc/usdt") {
            call.headers()
            try {
                val ts = timestamp(call.request.queryParameters.getAll("timestamp"))
                val rate = withContext(Dispatchers.IO) { prices.rate(ts) }
                call.respondText(buildJsonObject { put("timestamp", ts); put("btc_usdt", rate); put("unit", "sat_usdt") }.toString(), ContentType.Application.Json)
            } catch (error: QueryFailure) {
                call.respondText(error.message ?: "invalid query", ContentType.Text.Plain, HttpStatusCode.BadRequest)
            } catch (error: RateFailure) {
                call.respondText(buildJsonObject { put("error", error.message) }.toString(), ContentType.Application.Json, HttpStatusCode.fromValue(error.status))
            }
        }
    }
}

fun ApplicationCall.headers() {
    response.headers.append("X-Content-Type-Options", "nosniff")
    response.headers.append("X-Frame-Options", "DENY")
    response.headers.append("Referrer-Policy", "no-referrer")
    response.headers.append("Content-Security-Policy", "default-src 'none'")
    if (System.getenv("HTTPS") in listOf("1", "true")) response.headers.append("Strict-Transport-Security", "max-age=31536000; includeSubDomains")
}
