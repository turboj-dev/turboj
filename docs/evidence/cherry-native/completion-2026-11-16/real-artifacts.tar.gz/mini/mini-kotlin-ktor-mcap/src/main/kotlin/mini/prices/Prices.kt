package mini.prices

import com.zaxxer.hikari.HikariDataSource
import java.net.URI
import java.net.http.HttpClient
import java.net.http.HttpRequest
import java.net.http.HttpResponse
import java.time.Duration
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonPrimitive
import org.slf4j.LoggerFactory

class RateFailure(val status: Int, message: String) : RuntimeException(message)

class Prices(private val database: HikariDataSource, private val upstream: String) {
    private val log = LoggerFactory.getLogger(Prices::class.java)
    private val http = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(5)).build()
    init {
        val uri = URI(upstream)
        require(uri.scheme in listOf("http", "https") && uri.host != null) { "invalid BINANCE_API_BASE" }
        database.connection.use { connection -> connection.createStatement().use {
            it.execute("CREATE TABLE IF NOT EXISTS btc_usdt_rate (timestamp BIGINT PRIMARY KEY, btc_usdt BIGINT NOT NULL)")
        } }
    }
    fun rate(timestamp: Long): Long {
        if (timestamp !in 1577836800L..2000000000L) throw RateFailure(400, "invalid timestamp")
        val cached = try {
            database.connection.use { connection ->
                connection.prepareStatement("SELECT btc_usdt FROM btc_usdt_rate WHERE timestamp = ?").use { statement ->
                    statement.setLong(1, timestamp)
                    statement.executeQuery().use { rows -> if (rows.next()) rows.getLong(1) else null }
                }
            }
        } catch (error: java.sql.SQLException) {
            log.error("event=storage_read_failed type={}", error.javaClass.simpleName)
            throw RateFailure(503, "storage unavailable")
        }
        if (cached != null) {
            if (cached <= 0) throw RateFailure(500, "invalid btc usdt rate")
            return cached
        }
        val fetched = fetch(timestamp)
        try {
            database.connection.use { connection ->
                connection.prepareStatement("INSERT INTO btc_usdt_rate (timestamp, btc_usdt) VALUES (?, ?) ON CONFLICT (timestamp) DO UPDATE SET btc_usdt = EXCLUDED.btc_usdt").use { statement ->
                    statement.setLong(1, timestamp)
                    statement.setLong(2, fetched)
                    statement.executeUpdate()
                }
            }
        } catch (error: java.sql.SQLException) {
            log.error("event=storage_write_failed type={}", error.javaClass.simpleName)
            throw RateFailure(503, "storage unavailable")
        }
        return fetched
    }
    private fun fetch(timestamp: Long): Long {
        val close = try {
            val url = URI("${upstream.trimEnd('/')}/api/v3/klines?symbol=BTCUSDT&interval=1d&startTime=${timestamp * 1000}&limit=1")
            val response = http.send(HttpRequest.newBuilder(url).timeout(Duration.ofSeconds(10)).GET().build(), HttpResponse.BodyHandlers.ofString())
            if (response.statusCode() !in 200..299) throw RateFailure(502, "rate upstream unavailable")
            val price = Json.parseToJsonElement(response.body()).jsonArray.first().jsonArray[4].jsonPrimitive
            if (!price.isString) throw RateFailure(502, "rate upstream unavailable")
            price.content
        } catch (error: InterruptedException) {
            Thread.currentThread().interrupt()
            throw RateFailure(502, "rate upstream unavailable")
        } catch (error: Exception) {
            log.error("event=upstream_failed type={}", error.javaClass.simpleName)
            throw RateFailure(502, "rate upstream unavailable")
        }
        return convert(close)
    }
    companion object {
        fun convert(text: String): Long {
            val value = text.toDoubleOrNull() ?: throw RateFailure(500, "invalid btc usdt rate")
            val rate = kotlin.math.floor(100000000.0 / value + 0.5)
            if (!value.isFinite() || value <= 0 || !rate.isFinite() || rate <= 0 || rate > Long.MAX_VALUE.toDouble()) throw RateFailure(500, "invalid btc usdt rate")
            return rate.toLong()
        }
    }
}

fun required(name: String): String = System.getenv(name)?.takeIf { it.isNotBlank() } ?: error("missing $name")

fun database(): HikariDataSource {
    val uri = URI(required("DATABASE_URL"))
    require(uri.scheme in listOf("postgres", "postgresql")) { "invalid DATABASE_URL" }
    val credentials = uri.userInfo?.split(':', limit = 2).orEmpty()
    return HikariDataSource().apply {
        jdbcUrl = "jdbc:postgresql://${uri.host}:${if (uri.port < 0) 5432 else uri.port}${uri.path}${if (uri.query == null) "" else "?${uri.query}"}"
        credentials.getOrNull(0)?.let { username = it }
        credentials.getOrNull(1)?.let { password = it }
        maximumPoolSize = 5
    }
}

class QueryFailure(message: String) : RuntimeException("Failed to deserialize query string: $message")

fun timestamp(values: List<String>?): Long {
    if (values == null) throw QueryFailure("missing field `timestamp`")
    if (values.size != 1) throw QueryFailure("duplicate field `timestamp`")
    val text = values.first()
    if (text.isEmpty()) throw QueryFailure("timestamp: cannot parse integer from empty string")
    if (!Regex("\\+?[0-9]+").matches(text)) throw QueryFailure("timestamp: invalid digit found in string")
    val number = text.toBigInteger()
    if (number.bitLength() > 64) throw QueryFailure("timestamp: number too large to fit in target type")
    if (number < 1577836800.toBigInteger() || number > 2000000000.toBigInteger()) throw RateFailure(400, "invalid timestamp")
    return number.longValueExact()
}
