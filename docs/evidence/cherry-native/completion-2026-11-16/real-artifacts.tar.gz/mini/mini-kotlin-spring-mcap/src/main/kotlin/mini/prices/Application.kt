package mini.prices

import jakarta.servlet.FilterChain
import jakarta.servlet.http.HttpServletRequest
import jakarta.servlet.http.HttpServletResponse
import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication
import org.springframework.context.annotation.Bean
import org.springframework.http.MediaType
import org.springframework.http.ResponseEntity
import org.springframework.stereotype.Component
import org.springframework.web.bind.annotation.ExceptionHandler
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.RestController
import org.springframework.web.filter.OncePerRequestFilter
import java.nio.file.Files
import java.nio.file.Path

@SpringBootApplication
class Application {
    @Bean(destroyMethod = "close") fun pool() = database()
    @Bean fun prices(pool: com.zaxxer.hikari.HikariDataSource) = Prices(pool, required("BINANCE_API_BASE"))
}

fun main(args: Array<String>) {
    runApplication<Application>(*args) { setDefaultProperties(mapOf("server.port" to (System.getenv("PORT") ?: "3001"))) }
}

@RestController
class Api(private val prices: Prices) {
    @GetMapping("/health") fun health() = mapOf("status" to "ok")
    @GetMapping("/btc/usdt") fun price(request: HttpServletRequest): Map<String, Any> {
        val ts = timestamp(request.getParameterValues("timestamp")?.toList())
        return mapOf("timestamp" to ts, "btc_usdt" to prices.rate(ts), "unit" to "sat_usdt")
    }
    @GetMapping("/api-docs/openapi.json", produces = ["application/json"])
    fun openapi(): String = Files.readString(Path.of(required("OPENAPI_PATH")))
    @ExceptionHandler(RateFailure::class)
    fun rateFailure(error: RateFailure) = ResponseEntity.status(error.status).body(mapOf("error" to error.message))
    @ExceptionHandler(QueryFailure::class)
    fun queryFailure(error: QueryFailure) = ResponseEntity.badRequest().contentType(MediaType.parseMediaType("text/plain;charset=utf-8")).body(error.message)
}

@Component
class SecurityHeaders : OncePerRequestFilter() {
    override fun doFilterInternal(request: HttpServletRequest, response: HttpServletResponse, chain: FilterChain) {
        response.setHeader("X-Content-Type-Options", "nosniff")
        response.setHeader("X-Frame-Options", "DENY")
        response.setHeader("Referrer-Policy", "no-referrer")
        response.setHeader("Content-Security-Policy", "default-src 'none'")
        if (System.getenv("HTTPS") in listOf("1", "true")) response.setHeader("Strict-Transport-Security", "max-age=31536000; includeSubDomains")
        chain.doFilter(request, response)
    }
}
