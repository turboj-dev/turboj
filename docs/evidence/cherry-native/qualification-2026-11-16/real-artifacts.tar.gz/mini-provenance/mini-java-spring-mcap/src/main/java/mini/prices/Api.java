package mini.prices;

import java.math.BigInteger;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public final class Api {
    private final Prices prices;
    public Api(Prices prices) { this.prices = prices; }
    @GetMapping("/health")
    Map<String, String> health() { return Map.of("status", "ok"); }
    @GetMapping("/btc/usdt")
    ResponseEntity<?> price(HttpServletRequest request) {
        String[] values = request.getParameterValues("timestamp");
        if (values == null) return queryError("missing field `timestamp`");
        if (values.length != 1) return queryError("duplicate field `timestamp`");
        String text = values[0];
        if (text.isEmpty()) return queryError("timestamp: cannot parse integer from empty string");
        if (!text.matches("\\+?[0-9]+")) return queryError("timestamp: invalid digit found in string");
        BigInteger timestamp = new BigInteger(text);
        if (timestamp.bitLength() > 64) return queryError("timestamp: number too large to fit in target type");
        if (timestamp.compareTo(BigInteger.valueOf(1577836800)) < 0 || timestamp.compareTo(BigInteger.valueOf(2000000000)) > 0) throw new RateFailure(400, "invalid timestamp");
        long ts = timestamp.longValueExact();
        return ResponseEntity.ok(Map.of("timestamp", ts, "btc_usdt", prices.rate(ts), "unit", "sat_usdt"));
    }
    @GetMapping(value = "/api-docs/openapi.json", produces = "application/json")
    String openapi() throws java.io.IOException { return Files.readString(Path.of(Application.required("OPENAPI_PATH"))); }
    @ExceptionHandler(RateFailure.class)
    ResponseEntity<?> failure(RateFailure error) { return ResponseEntity.status(error.status()).body(Map.of("error", error.getMessage())); }
    private ResponseEntity<String> queryError(String message) { return ResponseEntity.badRequest().contentType(MediaType.parseMediaType("text/plain;charset=utf-8")).body("Failed to deserialize query string: " + message); }
}
