package mini.prices;

import java.net.URI;
import java.util.Map;
import javax.sql.DataSource;
import com.zaxxer.hikari.HikariDataSource;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class Application {
    public static void main(String[] args) {
        SpringApplication app = new SpringApplication(Application.class);
        app.setDefaultProperties(Map.of("server.port", System.getenv().getOrDefault("PORT", "3001")));
        app.run(args);
    }
    @Bean
    DataSource dataSource() {
        URI uri = URI.create(required("DATABASE_URL"));
        if (!"postgres".equals(uri.getScheme()) && !"postgresql".equals(uri.getScheme())) {
            throw new IllegalArgumentException("DATABASE_URL must use postgres");
        }
        String[] credentials = uri.getUserInfo() == null ? new String[0] : uri.getUserInfo().split(":", 2);
        HikariDataSource source = new HikariDataSource();
        source.setJdbcUrl("jdbc:postgresql://" + uri.getHost() + ":" + (uri.getPort() < 0 ? 5432 : uri.getPort()) + uri.getPath() + (uri.getQuery() == null ? "" : "?" + uri.getQuery()));
        if (credentials.length > 0) source.setUsername(credentials[0]);
        if (credentials.length > 1) source.setPassword(credentials[1]);
        source.setMaximumPoolSize(5);
        return source;
    }
    static String required(String name) {
        String value = System.getenv(name);
        if (value == null || value.isBlank()) throw new IllegalArgumentException("missing " + name);
        return value;
    }
}
