package mini.prices;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import tools.jackson.databind.ObjectMapper;

@Service
public final class Prices {
    private static final Logger LOG = LoggerFactory.getLogger(Prices.class);
    private final JdbcTemplate db;
    private final ObjectMapper json;
    private final HttpClient http = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(5)).build();
    private final String upstream;
    public Prices(JdbcTemplate db, ObjectMapper json) {
        this.db = db;
        this.json = json;
        upstream = Application.required("BINANCE_API_BASE").replaceAll("/+$", "");
        URI base = URI.create(upstream);
        if (!("http".equals(base.getScheme()) || "https".equals(base.getScheme())) || base.getHost() == null) throw new IllegalArgumentException("invalid BINANCE_API_BASE");
        db.execute("CREATE TABLE IF NOT EXISTS btc_usdt_rate (timestamp BIGINT PRIMARY KEY, btc_usdt BIGINT NOT NULL)");
    }
    public long rate(long timestamp) {
        if (timestamp < 1577836800L || timestamp > 2000000000L) throw new RateFailure(400, "invalid timestamp");
        List<Long> cached;
        try { cached = db.query("SELECT btc_usdt FROM btc_usdt_rate WHERE timestamp = ?", (row, index) -> row.getLong(1), timestamp); }
        catch (RuntimeException error) { LOG.error("event=storage_read_failed type={}", error.getClass().getSimpleName()); throw new RateFailure(503, "storage unavailable"); }
        if (!cached.isEmpty()) {
            if (cached.getFirst() <= 0) throw new RateFailure(500, "invalid btc usdt rate");
            return cached.getFirst();
        }
        long value = fetch(timestamp);
        try { db.update("INSERT INTO btc_usdt_rate (timestamp, btc_usdt) VALUES (?, ?) ON CONFLICT (timestamp) DO UPDATE SET btc_usdt = EXCLUDED.btc_usdt", timestamp, value); }
        catch (RuntimeException error) { LOG.error("event=storage_write_failed type={}", error.getClass().getSimpleName()); throw new RateFailure(503, "storage unavailable"); }
        return value;
    }
    private long fetch(long timestamp) {
        String close;
        try {
            URI uri = URI.create(upstream + "/api/v3/klines?symbol=BTCUSDT&interval=1d&startTime=" + timestamp * 1000 + "&limit=1");
            HttpResponse<String> response = http.send(HttpRequest.newBuilder(uri).timeout(Duration.ofSeconds(10)).GET().build(), HttpResponse.BodyHandlers.ofString());
            if (response.statusCode() < 200 || response.statusCode() >= 300) throw new RateFailure(502, "rate upstream unavailable");
            var node = json.readTree(response.body()).path(0).path(4);
            if (!node.isString()) throw new RateFailure(502, "rate upstream unavailable");
            close = node.asString();
        } catch (InterruptedException error) { Thread.currentThread().interrupt(); throw new RateFailure(502, "rate upstream unavailable"); }
        catch (RateFailure error) { throw error; }
        catch (Exception error) { LOG.error("event=upstream_failed type={}", error.getClass().getSimpleName()); throw new RateFailure(502, "rate upstream unavailable"); }
        return convert(close);
    }
    public static long convert(String price) {
        try {
            double amount = Double.parseDouble(price);
            double rate = Math.floor(100000000.0 / amount + 0.5);
            if (!Double.isFinite(amount) || amount <= 0 || !Double.isFinite(rate) || rate <= 0 || rate > Long.MAX_VALUE) throw new NumberFormatException();
            return (long) rate;
        } catch (NumberFormatException error) { throw new RateFailure(500, "invalid btc usdt rate"); }
    }
}
