package mini.prices;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class PricesTest {
    @Test void convertsPriceToSatoshisPerUsdt() { assertEquals(1468, Prices.convert("68124.19")); }
    @Test void roundsHalfUp() { assertEquals(3, Prices.convert("40000000")); }
    @Test void rejectsInvalidRates() {
        for (String value : new String[]{"0", "-1", "NaN", "Infinity", "invalid", "1e300"}) {
            RateFailure failure = assertThrows(RateFailure.class, () -> Prices.convert(value));
            assertEquals(500, failure.status());
        }
    }
}
