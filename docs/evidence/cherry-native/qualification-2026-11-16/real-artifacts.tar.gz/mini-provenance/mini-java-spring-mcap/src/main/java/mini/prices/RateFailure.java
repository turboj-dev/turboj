package mini.prices;

public final class RateFailure extends RuntimeException {
    private final int status;
    public RateFailure(int status, String message) {
        super(message);
        this.status = status;
    }
    public int status() { return status; }
}
