package mini.slack;

import static mini.slack.Json.*;
import static org.assertj.core.api.Assertions.*;

import java.net.URI;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpTimeoutException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Executors;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EnumSource;
import tools.jackson.databind.JsonNode;
import tools.jackson.databind.node.ObjectNode;

class MiniSlackHttpTest {
    private MiniSlackServer server;
    private HttpFixture http;

    @BeforeEach
    void start() throws Exception {
        server = MiniSlackServer.local();
        server.seed(Fixtures.load("empty"));
        http = new HttpFixture(server);
    }

    @AfterEach
    void stop() {
        if (http != null) {
            http.close();
        }
        if (server != null) {
            server.close();
        }
    }

    @Test
    void authenticates_user_and_bot_without_scopes() throws Exception {
        assertThat(http.post("auth.test", object()).path("team_id").asString()).isEqualTo(HttpFixture.WORKSPACE);
        http.token = http.token("UBOT000001", List.of(), false, false, 0);
        JsonNode auth = http.post("auth.test", object());
        assertThat(auth.path("user_id").asString()).isEqualTo("UBOT000001");
        assertThat(auth.has("bot_id")).isTrue();
    }

    @Test
    void missing_invalid_revoked_and_expired_tokens_keep_http_200() throws Exception {
        for (String[] row : new String[][] {
            {"", "not_authed"},
            {"xoxb-mini-invalid", "invalid_auth"},
            {http.token("UADMIN0001", List.of(), false, true, 0), "token_revoked"},
            {http.token("UADMIN0001", List.of(), false, false, 1), "token_expired"}
        }) {
            http.token = row[0];
            assertError(http.post("auth.test", object()), row[1]);
        }
    }

    @Test
    void deactivated_principal_cannot_authenticate() throws Exception {
        http.control("POST", "/_test/users/UADMIN0001/deactivate", object("workspaceId", HttpFixture.WORKSPACE));
        assertError(http.post("auth.test", object()), "account_inactive");
    }

    @Test
    void scope_checks_do_not_leak_email() throws Exception {
        http.token = http.token("UADMIN0001", List.of("users:read"), false, false, 0);
        assertThat(http.get("users.list").toString()).doesNotContain("@", "email");
        assertThat(http.get("users.info?user=UADMIN0001").toString()).doesNotContain("@", "email");
        assertError(http.get("users.lookupByEmail?email=admin%40example.test"), "missing_scope");
        http.token = http.token("UADMIN0001", List.of("users:read.email"), false, false, 0);
        assertThat(http.get("users.lookupByEmail?email=admin%40example.test")
                        .path("ok")
                        .asBoolean())
                .isTrue();
        assertError(http.get("users.list"), "missing_scope");
        assertError(http.get("users.info?user=UADMIN0001"), "missing_scope");
    }

    @Test
    void lists_invited_and_deactivated_but_lookup_requires_active() throws Exception {
        String id = http.addUser("inactive@example.test").path("id").asString();
        http.control("POST", "/_test/users/" + id + "/deactivate", object("workspaceId", HttpFixture.WORKSPACE));
        JsonNode invitation = http.control(
                "POST",
                "/_test/invitations",
                object(
                        "workspaceId",
                        HttpFixture.WORKSPACE,
                        "email",
                        "pending@example.test",
                        "channel_ids",
                        "CLOCAL0001"));
        JsonNode inactive = http.get("users.info?user=" + id).path("user");
        assertThat(inactive.path("deleted").asBoolean()).isTrue();
        assertError(http.get("users.lookupByEmail?email=inactive%40example.test"), "users_not_found");
        assertError(http.get("users.lookupByEmail?email=pending%40example.test"), "users_not_found");
        assertThat(http.get("users.list").path("members")).hasSize(4);
        assertThat(http.get("users.info?user=" + invitation.path("userId").asString())
                        .path("user")
                        .path("is_invited_user")
                        .asBoolean())
                .isTrue();
    }

    @Test
    void users_validation_duplicates_missing_profiles_and_bots() throws Exception {
        assertError(http.get("users.lookupByEmail"), "invalid_arguments");
        assertError(http.get("users.lookupByEmail?email=absent%40example.test"), "users_not_found");
        assertError(http.get("users.info?user=UABSENT1"), "user_not_found");
        assertThat(http.get("users.info?user=UBOT000001")
                        .path("user")
                        .path("is_bot")
                        .asBoolean())
                .isTrue();
        assertThat(http.get("users.info?user=UBOT000001")
                        .path("user")
                        .path("profile")
                        .has("email"))
                .isFalse();
        http.addUser("unique@example.test");
        HttpResponse<String> duplicate = http.raw(
                "POST",
                "/_test/users",
                object("workspaceId", HttpFixture.WORKSPACE, "email", "UNIQUE@example.test"),
                "",
                true,
                Duration.ofSeconds(2));
        assertThat(duplicate.statusCode()).isEqualTo(409);
    }

    @Test
    void cursor_pagination_is_repeatable_and_rejects_foreign_cursors() throws Exception {
        ObjectNode fixture = (ObjectNode) Fixtures.load("large");
        server.seed(fixture);
        http.token = http.token("UADMIN0001", HttpFixture.SCOPES, true, false, 0);
        JsonNode first = http.get("users.list?limit=137");
        assertThat(http.get("users.list?limit=137")).isEqualTo(first);
        String cursor = first.path("response_metadata").path("next_cursor").asString();
        assertError(http.get("conversations.list?cursor=" + cursor), "invalid_cursor");
        assertError(http.get("users.list?cursor=broken"), "invalid_cursor");
        assertError(http.get("users.list?limit=0"), "invalid_arguments");
        Set<String> ids = new HashSet<>();
        String next = "";
        do {
            JsonNode page = http.get("users.list?limit=137&cursor=" + next);
            for (JsonNode user : page.path("members")) {
                assertThat(ids.add(user.path("id").asString())).isTrue();
            }
            next = page.path("response_metadata").path("next_cursor").asString();
        } while (!next.isEmpty());
        assertThat(ids).hasSize(1003);
        assertThat(http.get("users.lookupByEmail?email=member1000%40example.test")
                        .path("user")
                        .path("id")
                        .asString())
                .isEqualTo("ULARGE001000");
    }

    @Test
    void reset_invalidates_tokens_and_cursors_and_seed_is_atomic() throws Exception {
        JsonNode before = http.state();
        HttpResponse<String> badSeed = http.raw(
                "POST",
                "/_test/seed",
                object("workspaces", List.of(object("id", "TVALID1", "name", "valid"), object("id", "bad"))),
                "",
                true,
                Duration.ofSeconds(2));
        assertThat(badSeed.statusCode()).isEqualTo(400);
        assertThat(http.state()).isEqualTo(before);
        http.control("POST", "/_test/reset", object());
        assertThat(http.state().path("workspaces")).isEmpty();
        assertError(http.post("auth.test", object()), "invalid_auth");
        assertThat(server.requests()).hasSize(1);
    }

    @Test
    void isolates_workspaces_and_token_contexts() throws Exception {
        http.control("POST", "/_test/workspaces", object("id", "TOTHER001", "name", "Other", "plan", "FREE"));
        http.control(
                "POST",
                "/_test/users",
                object("workspaceId", "TOTHER001", "id", "UOTHER001", "email", "other@example.test"));
        assertError(http.get("users.info?user=UOTHER001"), "user_not_found");
        assertError(http.get("users.list?team_id=TOTHER001"), "team_access_not_granted");
        http.token = http.token("UADMIN0001", HttpFixture.SCOPES, false, false, 0);
        assertThat(http.get("users.list?team_id=TOTHER001").path("members")).hasSize(2);
    }

    @ParameterizedTest
    @EnumSource(Plan.class)
    void enforces_subscription_capabilities(Plan plan) throws Exception {
        http.plan(plan);
        JsonNode invite = http.post(
                "admin.users.invite",
                object("team_id", HttpFixture.WORKSPACE, "email", "new@example.test", "channel_ids", "CLOCAL0001"));
        if (plan == Plan.ENTERPRISE) {
            assertThat(invite.path("ok").asBoolean()).isTrue();
        } else {
            assertError(invite, "feature_not_enabled");
        }
        HttpResponse<String> scim =
                http.raw("GET", "/scim/v2/Users", object(), http.token, false, Duration.ofSeconds(2));
        assertThat(scim.statusCode()).isEqualTo(plan == Plan.FREE ? 403 : 200);
        assertThat(MAPPER.readTree(scim.body()).has("ok")).isFalse();
    }

    @Test
    void enterprise_invitation_is_pending_until_explicit_acceptance() throws Exception {
        http.plan(Plan.ENTERPRISE);
        JsonNode input = object(
                "team_id",
                HttpFixture.WORKSPACE,
                "email",
                "new@example.test",
                "channel_ids",
                "CLOCAL0001",
                "real_name",
                "Synthetic New",
                "custom_message",
                "Welcome");
        assertThat(http.post("admin.users.invite", input)).isEqualTo(object("ok", true));
        assertError(http.post("admin.users.invite", input), "already_in_team_invited_user");
        JsonNode invite =
                http.state().path("workspaces").get(0).path("invitations").get(0);
        assertThat(http.get("conversations.members?channel=CLOCAL0001").path("members"))
                .hasSize(2);
        http.control(
                "POST",
                "/_test/invitations/" + invite.path("id").asString() + "/accept",
                object("workspaceId", HttpFixture.WORKSPACE));
        assertThat(http.get("users.lookupByEmail?email=new%40example.test")
                        .path("ok")
                        .asBoolean())
                .isTrue();
        assertThat(http.get("conversations.members?channel=CLOCAL0001").path("members"))
                .hasSize(3);
        assertError(http.post("admin.users.invite", input), "already_in_team");
    }

    @Test
    void rejects_invitation_without_activating_user() throws Exception {
        JsonNode invite = http.control(
                "POST",
                "/_test/invitations",
                object("workspaceId", HttpFixture.WORKSPACE, "email", "no@example.test", "channel_ids", "CLOCAL0001"));
        http.control(
                "POST",
                "/_test/invitations/" + invite.path("id").asString() + "/reject",
                object("workspaceId", HttpFixture.WORKSPACE));
        assertError(http.get("users.lookupByEmail?email=no%40example.test"), "users_not_found");
        assertThat(http.get("users.list").path("members")).hasSize(2);
        assertThat(http.raw(
                                "POST",
                                "/_test/invitations/" + invite.path("id").asString() + "/accept",
                                object("workspaceId", HttpFixture.WORKSPACE),
                                "",
                                true,
                                Duration.ofSeconds(2))
                        .statusCode())
                .isEqualTo(409);
    }

    @Test
    void admin_requires_user_org_token_scope_and_role() throws Exception {
        http.plan(Plan.ENTERPRISE);
        JsonNode request =
                object("team_id", HttpFixture.WORKSPACE, "email", "new@example.test", "channel_ids", "CLOCAL0001");
        http.token = http.token("UBOT000001", HttpFixture.SCOPES, true, false, 0);
        assertError(http.post("admin.users.invite", request), "not_allowed_token_type");
        http.token = http.token("UADMIN0001", List.of(), true, false, 0);
        assertError(http.post("admin.users.invite", request), "missing_scope");
        String member = http.addUser("member@example.test").path("id").asString();
        http.token = http.token(member, HttpFixture.SCOPES, true, false, 0);
        assertError(http.post("admin.users.invite", request), "not_an_admin");
        http.token = http.token("UADMIN0001", HttpFixture.SCOPES, false, false, 0);
        assertError(http.post("admin.users.invite", request), "not_allowed_token_type");
    }

    @Test
    void admin_validates_channels_workspace_and_primary_owner() throws Exception {
        http.plan(Plan.ENTERPRISE);
        assertError(
                http.post(
                        "admin.users.invite",
                        object("team_id", "TOTHER001", "email", "new@example.test", "channel_ids", "CLOCAL0001")),
                "team_access_not_granted");
        assertError(
                http.post(
                        "admin.users.invite",
                        object(
                                "team_id",
                                HttpFixture.WORKSPACE,
                                "email",
                                "new@example.test",
                                "channel_ids",
                                "CABSENT1")),
                "failed_to_validate_channels");
        http.control(
                "POST",
                "/_test/users",
                object("workspaceId", HttpFixture.WORKSPACE, "id", "UOWNER001", "is_primary_owner", true));
        assertError(
                http.post("admin.users.remove", object("team_id", HttpFixture.WORKSPACE, "user_id", "UOWNER001")),
                "cannot_modify_primary_owner");
    }

    @Test
    void private_channels_require_membership_even_with_scope() throws Exception {
        http.token = http.token("UBOT000001", HttpFixture.SCOPES, false, false, 0);
        assertThat(http.get("conversations.list?types=public_channel,private_channel")
                        .path("channels"))
                .hasSize(8);
        assertError(http.get("conversations.info?channel=CLOCAL0009"), "channel_not_found");
        assertError(
                http.post("conversations.invite", object("channel", "CLOCAL0009", "users", "UADMIN0001")),
                "channel_not_found");
    }

    @Test
    void channel_membership_cannot_provision_workspace_members_and_bulk_is_atomic() throws Exception {
        String user = http.addUser("channel@example.test").path("id").asString();
        assertError(
                http.post("conversations.invite", object("channel", "CLOCAL0001", "users", user + ",UUNKNOWN1")),
                "user_not_found");
        assertThat(http.get("conversations.members?channel=CLOCAL0001").path("members"))
                .hasSize(2);
        assertThat(http.post("conversations.invite", object("channel", "CLOCAL0001", "users", user))
                        .path("ok")
                        .asBoolean())
                .isTrue();
        assertError(
                http.post("conversations.invite", object("channel", "CLOCAL0001", "users", user)),
                "already_in_channel");
        assertError(
                http.post("conversations.invite", object("channel", "CABSENT1", "users", user)), "channel_not_found");
        assertThat(http.post("conversations.kick", object("channel", "CLOCAL0001", "user", user))
                        .path("ok")
                        .asBoolean())
                .isTrue();
        assertThat(http.get("users.info?user=" + user)
                        .path("user")
                        .path("deleted")
                        .asBoolean())
                .isFalse();
        http.control("POST", "/_test/users/" + user + "/deactivate", object("workspaceId", HttpFixture.WORKSPACE));
        assertError(
                http.post("conversations.invite", object("channel", "CLOCAL0001", "users", user)), "user_not_found");
    }

    @Test
    void channel_read_and_write_scopes_are_distinct() throws Exception {
        String user = http.addUser("channel@example.test").path("id").asString();
        http.token = http.token("UBOT000001", List.of("channels:read"), false, false, 0);
        assertThat(http.get("conversations.info?channel=CLOCAL0001").path("ok").asBoolean())
                .isTrue();
        assertError(http.post("conversations.invite", object("channel", "CLOCAL0001", "users", user)), "missing_scope");
        http.token = http.token(user, HttpFixture.SCOPES, false, false, 0);
        assertError(
                http.post("conversations.invite", object("channel", "CLOCAL0001", "users", "UBOT000001")),
                "not_in_channel");
    }

    @Test
    void scim_provisions_patches_deactivates_and_reactivates() throws Exception {
        http.plan(Plan.BUSINESS_PLUS);
        HttpResponse<String> create = scim(
                "POST",
                "/scim/v2/Users",
                object(
                        "schemas",
                        List.of(ScimApi.USER_SCHEMA),
                        "userName",
                        "scimuser",
                        "emails",
                        List.of(object("value", "scim@example.test", "primary", true))));
        assertThat(create.statusCode()).isEqualTo(201);
        String id = MAPPER.readTree(create.body()).path("id").asString();
        assertThat(http.get("users.lookupByEmail?email=scim%40example.test")
                        .path("user")
                        .path("id")
                        .asString())
                .isEqualTo(id);
        HttpResponse<String> patched = scim(
                "PATCH",
                "/scim/v2/Users/" + id,
                object(
                        "schemas",
                        List.of(ScimApi.PATCH_SCHEMA),
                        "Operations",
                        List.of(object("op", "replace", "path", "displayName", "value", "New name"))));
        assertThat(MAPPER.readTree(patched.body()).path("displayName").asString())
                .isEqualTo("New name");
        assertThat(scim("DELETE", "/scim/v2/Users/" + id, object()).statusCode())
                .isEqualTo(204);
        assertError(http.get("users.lookupByEmail?email=scim%40example.test"), "users_not_found");
        assertThat(http.get("users.info?user=" + id)
                        .path("user")
                        .path("deleted")
                        .asBoolean())
                .isTrue();
        assertThat(scim("PATCH", "/scim/v2/Users/" + id, activePatch(true)).statusCode())
                .isEqualTo(200);
        assertThat(http.get("users.lookupByEmail?email=scim%40example.test")
                        .path("ok")
                        .asBoolean())
                .isTrue();
    }

    @Test
    void removal_is_not_global_scim_deactivation_or_implicit_rejoin() throws Exception {
        http.plan(Plan.ENTERPRISE);
        String id = http.addUser("removed@example.test").path("id").asString();
        assertThat(http.post("admin.users.remove", object("team_id", HttpFixture.WORKSPACE, "user_id", id))
                        .path("ok")
                        .asBoolean())
                .isTrue();
        assertError(http.get("users.info?user=" + id), "user_not_found");
        assertThat(MAPPER.readTree(scim("GET", "/scim/v2/Users/" + id, object()).body())
                        .path("active")
                        .asBoolean())
                .isTrue();
        scim("DELETE", "/scim/v2/Users/" + id, object());
        scim("PATCH", "/scim/v2/Users/" + id, activePatch(true));
        assertError(http.get("users.lookupByEmail?email=removed%40example.test"), "users_not_found");
    }

    @Test
    void scim_enforces_permissions_and_atomic_attribute_updates() throws Exception {
        http.plan(Plan.BUSINESS_PLUS);
        String id = http.addUser("attributes@example.test").path("id").asString();
        HttpResponse<String> bad = scim(
                "PATCH",
                "/scim/v2/Users/" + id,
                object(
                        "schemas",
                        List.of(ScimApi.PATCH_SCHEMA),
                        "Operations",
                        List.of(
                                object("op", "replace", "path", "displayName", "value", "must not persist"),
                                object("op", "replace", "path", "is_admin", "value", true))));
        assertThat(bad.statusCode()).isEqualTo(400);
        assertThat(http.get("users.info?user=" + id)
                        .path("user")
                        .path("profile")
                        .path("display_name")
                        .asString())
                .isEmpty();
        http.token = http.token("UBOT000001", List.of("admin"), false, false, 0);
        assertThat(scim("GET", "/scim/v2/Users", object()).statusCode()).isEqualTo(403);
        http.token = http.token("UADMIN0001", List.of(), false, false, 0);
        assertThat(scim("GET", "/scim/v2/Users", object()).statusCode()).isEqualTo(403);
        http.token = "invalid";
        assertThat(scim("GET", "/scim/v2/Users", object()).statusCode()).isEqualTo(401);
    }

    @Test
    void scim_list_paginates_and_does_not_invent_v2_filter_support() throws Exception {
        http.plan(Plan.BUSINESS_PLUS);
        http.addUser("one@example.test");
        http.addUser("two@example.test");
        JsonNode page = MAPPER.readTree(
                scim("GET", "/scim/v2/Users?count=1&startIndex=2", object()).body());
        assertThat(page.path("totalResults").asInt()).isEqualTo(3);
        assertThat(page.path("Resources")).hasSize(1);
        assertThat(scim("GET", "/scim/v2/Users?filter=" + HttpFixture.encode("userName eq \"one\""), object())
                        .statusCode())
                .isEqualTo(400);
        assertThat(scim("GET", "/scim/v2/Users/UUNKNOWN1", object()).statusCode())
                .isEqualTo(404);
    }

    @Test
    void deterministic_rate_limits_are_consumed_and_captured() throws Exception {
        http.fault(object("method", "users.list", "failNext", 2, "httpStatus", 429, "retryAfterSeconds", 1));
        for (int i = 0; i < 2; i++) {
            HttpResponse<String> response =
                    http.raw("GET", "/api/users.list", object(), http.token, false, Duration.ofSeconds(2));
            assertThat(response.statusCode()).isEqualTo(429);
            assertThat(response.headers().firstValue("Retry-After")).contains("1");
        }
        assertThat(http.get("users.list").path("ok").asBoolean()).isTrue();
        assertThat(server.requests()).hasSize(3);
        assertThat(server.requests().stream().filter(r -> r.path("status").asInt() == 429))
                .hasSize(2);
    }

    @Test
    void supports_unavailability_slack_errors_malformed_and_interrupted_pages() throws Exception {
        http.fault(object("method", "users.list", "httpStatus", 503));
        assertThat(http.raw("GET", "/api/users.list", object(), http.token, false, Duration.ofSeconds(2))
                        .statusCode())
                .isEqualTo(503);
        http.fault(object("method", "users.list", "error", "missing_scope"));
        assertError(http.get("users.list"), "missing_scope");
        http.fault(object("method", "users.list", "malformed", true));
        assertThat(http.raw("GET", "/api/users.list", object(), http.token, false, Duration.ofSeconds(2))
                        .body())
                .isEqualTo("{malformed");
        http.fault(object("method", "users.list", "incompletePage", true));
        JsonNode interrupted = http.get("users.list?limit=1");
        assertThat(interrupted.path("members")).hasSize(1);
        assertThat(interrupted.path("response_metadata").path("next_cursor").asString())
                .isEmpty();
        assertThat(http.get("users.list?limit=1")
                        .path("response_metadata")
                        .path("next_cursor")
                        .asString())
                .isNotEmpty();
    }

    @Test
    void delayed_request_can_timeout_without_blocking_control_or_other_requests() throws Exception {
        http.fault(object("method", "users.list", "delayMs", 300));
        assertThatThrownBy(() -> http.raw("GET", "/api/users.list", object(), http.token, false, Duration.ofMillis(50)))
                .isInstanceOf(HttpTimeoutException.class);
        assertThat(http.get("users.list").path("ok").asBoolean()).isTrue();
        http.control("DELETE", "/_test/faults", object());
    }

    @Test
    void credentials_and_profile_pii_are_redacted_in_evidence() throws Exception {
        http.post("auth.test", object("token", http.token, "email", "secret@example.test", "password", "private"));
        http.get("users.lookupByEmail?email=admin%40example.test&token=" + http.token);
        String captured = http.control("GET", "/_test/requests", object()).toString();
        assertThat(captured)
                .doesNotContain(http.token, "admin@example.test", "secret@example.test", "private")
                .contains("[REDACTED]");
        assertThat(http.state().path("tokens").toString()).doesNotContain(http.token);
        http.control("DELETE", "/_test/requests", object());
        assertThat(server.requests()).isEmpty();
    }

    @Test
    void test_control_requires_secret_and_rejects_real_token_shapes() throws Exception {
        assertThat(http.raw("GET", "/_test/state", object(), http.token, false, Duration.ofSeconds(2))
                        .statusCode())
                .isEqualTo(403);
        HttpResponse<String> real = http.raw(
                "POST",
                "/_test/tokens",
                object(
                        "workspaceId",
                        HttpFixture.WORKSPACE,
                        "principalId",
                        "UADMIN0001",
                        "token",
                        "xoxp-not-synthetic"),
                "",
                true,
                Duration.ofSeconds(2));
        assertThat(real.statusCode()).isEqualTo(400);
        HttpRequest origin = HttpRequest.newBuilder(server.baseUri().resolve("/_test/state"))
                .header("Origin", "http://untrusted.example.test")
                .header("X-Mini-Slack-Secret", server.testSecret())
                .GET()
                .build();
        assertThat(http.client
                        .send(origin, HttpResponse.BodyHandlers.ofString())
                        .statusCode())
                .isEqualTo(403);
    }

    @Test
    void supports_form_encoded_slack_clients() throws Exception {
        HttpRequest request = HttpRequest.newBuilder(server.baseUri().resolve("/api/auth.test"))
                .header("Content-Type", "application/x-www-form-urlencoded")
                .POST(HttpRequest.BodyPublishers.ofString("token=" + http.token))
                .build();
        assertThat(MAPPER.readTree(http.client
                                .send(request, HttpResponse.BodyHandlers.ofString())
                                .body())
                        .path("ok")
                        .asBoolean())
                .isTrue();
    }

    @Test
    void production_and_public_bind_guards_are_enforced() {
        assertThatThrownBy(() -> new MiniSlackServer.Settings("0.0.0.0", 0, "test", false, false, ""))
                .isInstanceOf(IllegalArgumentException.class);
        assertThatThrownBy(() -> new MiniSlackServer.Settings("127.0.0.1", 0, "production", false, false, ""))
                .isInstanceOf(IllegalArgumentException.class);
        assertThatThrownBy(() -> new MiniSlackServer.Settings("0.0.0.0", 0, "test", true, true, "short"))
                .isInstanceOf(IllegalArgumentException.class);
        assertThatThrownBy(() -> MiniSlackServer.rejectProduction(Map.of("SPRING_PROFILES_ACTIVE", "local,production")))
                .isInstanceOf(IllegalArgumentException.class);
        assertThatThrownBy(() -> SlackEndpoints.forEnvironment(
                        "production", URI.create(server.baseUri() + "/api"), URI.create(server.baseUri() + "/scim/v2")))
                .isInstanceOf(IllegalArgumentException.class);
        assertThatThrownBy(() -> SlackEndpoints.forEnvironment(
                        "test", URI.create("https://slack.com/api"), URI.create("https://api.slack.com/scim/v2")))
                .isInstanceOf(IllegalArgumentException.class);
        assertThat(server.environment("demo", "slack").get("SLACK_API_BASE_URL"))
                .isEqualTo(server.baseUri() + "/api");
    }

    @Test
    void test_api_can_be_disabled() throws Exception {
        try (MiniSlackServer isolated =
                new MiniSlackServer(new MiniSlackServer.Settings("127.0.0.1", 0, "test", false, false, ""))) {
            HttpRequest request = HttpRequest.newBuilder(isolated.baseUri().resolve("/_test/state"))
                    .GET()
                    .build();
            assertThat(http.client
                            .send(request, HttpResponse.BodyHandlers.ofString())
                            .statusCode())
                    .isEqualTo(404);
        }
    }

    @Test
    void independent_parallel_instances_have_no_shared_state() throws Exception {
        try (var executor = Executors.newVirtualThreadPerTaskExecutor()) {
            List<java.util.concurrent.Future<Integer>> results = new ArrayList<>();
            for (int i = 0; i < 4; i++) {
                results.add(executor.submit(() -> {
                    try (MiniSlackServer isolated = MiniSlackServer.local()) {
                        isolated.seed(Fixtures.load("empty"));
                        try (HttpFixture client = new HttpFixture(isolated)) {
                            client.addUser("same@example.test");
                            return client.get("users.list").path("members").size();
                        }
                    }
                }));
            }
            for (var result : results) {
                assertThat(result.get()).isEqualTo(3);
            }
        }
        assertThat(http.get("users.list").path("members")).hasSize(2);
    }

    private HttpResponse<String> scim(String method, String path, JsonNode input) throws Exception {
        return http.raw(method, path, input, http.token, false, Duration.ofSeconds(3));
    }

    @Test
    void admin_reinvitation_reactivates_an_existing_deactivated_account() throws Exception {
        http.plan(Plan.ENTERPRISE);
        String id = http.addUser("reactivated@example.test").path("id").asString();
        http.control("POST", "/_test/users/" + id + "/deactivate", object("workspaceId", HttpFixture.WORKSPACE));
        assertThat(http.post(
                                "admin.users.invite",
                                object(
                                        "team_id",
                                        HttpFixture.WORKSPACE,
                                        "email",
                                        "reactivated@example.test",
                                        "channel_ids",
                                        "CLOCAL0001"))
                        .path("ok")
                        .asBoolean())
                .isTrue();
        assertThat(http.get("users.lookupByEmail?email=reactivated%40example.test")
                        .path("user")
                        .path("id")
                        .asString())
                .isEqualTo(id);
        assertThat(http.state().path("workspaces").get(0).path("invitations")).isEmpty();
    }

    @Test
    void invalid_role_and_token_context_changes_do_not_commit() throws Exception {
        JsonNode before = http.state();
        assertThat(http.raw(
                                "PATCH",
                                "/_test/users/UADMIN0001",
                                object("workspaceId", HttpFixture.WORKSPACE, "is_admin", "nonsense"),
                                "",
                                true,
                                Duration.ofSeconds(2))
                        .statusCode())
                .isEqualTo(400);
        assertThat(http.state()).isEqualTo(before);
        assertThat(http.raw(
                                "POST",
                                "/_test/tokens",
                                object(
                                        "workspaceId",
                                        HttpFixture.WORKSPACE,
                                        "principalId",
                                        "UBOT000001",
                                        "type",
                                        "user"),
                                "",
                                true,
                                Duration.ofSeconds(2))
                        .statusCode())
                .isEqualTo(400);
    }

    @Test
    void scim_errors_follow_the_protocol_and_username_uniqueness() throws Exception {
        JsonNode free = MAPPER.readTree(scim("GET", "/scim/v2/Users", object()).body());
        assertThat(free.path("detail").asString()).isEqualTo("plus_teams_only");
        assertThat(free.path("status").asInt()).isEqualTo(403);
        http.plan(Plan.BUSINESS_PLUS);
        JsonNode create = object(
                "schemas",
                List.of(ScimApi.USER_SCHEMA),
                "userName",
                "admin",
                "emails",
                List.of(object("value", "new@example.test")));
        assertThat(MAPPER.readTree(scim("POST", "/scim/v2/Users", create).body())
                        .path("detail")
                        .asString())
                .isEqualTo("username_taken");
        HttpResponse<String> missing =
                http.raw("GET", "/scim/v2/Users?token=" + http.token, object(), "", false, Duration.ofSeconds(2));
        assertThat(MAPPER.readTree(missing.body()).path("detail").asString()).isEqualTo("missing_authentication");
        http.token = "invalid";
        assertThat(MAPPER.readTree(scim("GET", "/scim/v2/Users", object()).body())
                        .path("detail")
                        .asString())
                .isEqualTo("invalid_authentication");
    }

    @Test
    void bulk_force_explicitly_processes_valid_channel_invites() throws Exception {
        String id = http.addUser("bulk@example.test").path("id").asString();
        JsonNode result = http.post(
                "conversations.invite", object("channel", "CLOCAL0001", "users", id + ",UNOTFOUND", "force", true));
        assertThat(result.path("errors")).hasSize(1);
        assertThat(http.get("conversations.members?channel=CLOCAL0001").path("members"))
                .hasSize(3);
    }

    @Test
    void failed_seed_does_not_start_a_listening_server() throws Exception {
        assertThatThrownBy(() -> new MiniSlackServer(
                        MiniSlackServer.Settings.local(), java.time.Clock.systemUTC(), object("invalid", true)))
                .isInstanceOf(ApiException.class);
    }

    private static JsonNode activePatch(boolean active) {
        return object(
                "schemas",
                List.of(ScimApi.PATCH_SCHEMA),
                "Operations",
                List.of(object("op", "replace", "path", "active", "value", active)));
    }

    static void assertError(JsonNode response, String error) {
        assertThat(response.path("ok").asBoolean()).isFalse();
        assertThat(response.path("error").asString()).isEqualTo(error);
    }
}
