package mini.slack;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import org.jspecify.annotations.Nullable;
import tools.jackson.databind.JsonNode;
import tools.jackson.databind.json.JsonMapper;
import tools.jackson.databind.node.ArrayNode;
import tools.jackson.databind.node.ObjectNode;

final class Json {
    static final JsonMapper MAPPER = JsonMapper.builder().build();

    private Json() {}

    static ObjectNode object(@Nullable Object... pairs) {
        ObjectNode node = MAPPER.createObjectNode();
        for (int i = 0; i < pairs.length; i += 2) {
            node.set(Objects.requireNonNull((String) pairs[i]), MAPPER.valueToTree(pairs[i + 1]));
        }
        return node;
    }

    static ArrayNode array(Iterable<?> values) {
        ArrayNode node = MAPPER.createArrayNode();
        values.forEach(value -> node.add(MAPPER.valueToTree(value)));
        return node;
    }

    static String text(JsonNode node, String key, String fallback) {
        return node.path(key).asString(fallback);
    }

    static String required(JsonNode node, String key) {
        String value = text(node, key, "");
        if (value.isBlank() || value.length() > 4096) {
            throw new ApiException("invalid_arguments");
        }
        return value;
    }

    static int integer(JsonNode node, String key, int fallback, int min, int max) {
        if (!node.has(key)) {
            return fallback;
        }
        try {
            int value = Integer.parseInt(node.path(key).asString());
            if (value < min || value > max) {
                throw new ApiException("invalid_arguments");
            }
            return value;
        } catch (NumberFormatException exception) {
            throw new ApiException("invalid_arguments");
        }
    }

    static boolean bool(JsonNode node, String key, boolean fallback) {
        if (!node.has(key)) {
            return fallback;
        }
        return switch (node.path(key).asString()) {
            case "true", "1" -> true;
            case "false", "0" -> false;
            default -> throw new ApiException("invalid_arguments");
        };
    }

    static List<String> strings(JsonNode node) {
        List<String> result = new ArrayList<>();
        if (node.isMissingNode() || node.isNull()) {
            return result;
        }
        if (node.isArray()) {
            node.forEach(item -> result.add(item.asString()));
        } else {
            for (String value : node.asString().split(",", -1)) {
                if (!value.isBlank()) {
                    result.add(value.trim());
                }
            }
        }
        return result;
    }

    static String email(String email) {
        if (!email.matches("[^\\s@]+@[^\\s@]+\\.[^\\s@]+") || email.length() > 254) {
            throw new ApiException("invalid_email");
        }
        return email.toLowerCase(Locale.ROOT);
    }
}
