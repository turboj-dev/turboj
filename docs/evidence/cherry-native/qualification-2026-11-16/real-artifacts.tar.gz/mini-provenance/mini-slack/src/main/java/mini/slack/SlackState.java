package mini.slack;

import static mini.slack.Json.*;

import java.time.Clock;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import tools.jackson.databind.JsonNode;
import tools.jackson.databind.node.ObjectNode;

final class SlackState {
    enum Lifecycle {
        INVITED,
        ACTIVE,
        DEACTIVATED,
        REMOVED
    }

    static final class User {
        final String id;
        final long created;
        ObjectNode attributes;
        Lifecycle lifecycle;
        boolean accountActive;
        long updated;

        User(String id, ObjectNode attributes, long time) {
            this.id = id;
            this.attributes = attributes;
            this.created = time;
            this.updated = time;
            this.lifecycle = lifecycle(text(attributes, "state", "ACTIVE"));
            this.accountActive = bool(attributes, "accountActive", lifecycle != Lifecycle.DEACTIVATED);
        }

        boolean flag(String name) {
            return bool(attributes, name, false);
        }

        String value(String name) {
            return text(attributes, name, "");
        }

        int rank() {
            return flag("is_primary_owner") ? 3 : flag("is_owner") ? 2 : flag("is_admin") ? 1 : 0;
        }

        boolean active() {
            return lifecycle == Lifecycle.ACTIVE && accountActive;
        }

        ObjectNode slack(String workspaceId, boolean emailVisible) {
            ObjectNode profile = object(
                    "real_name",
                    value("real_name"),
                    "display_name",
                    value("display_name"),
                    "first_name",
                    value("first_name"),
                    "last_name",
                    value("last_name"),
                    "image_48",
                    value("avatar_url"));
            if (emailVisible && attributes.hasNonNull("email")) {
                profile.put("email", value("email"));
            }
            return object(
                    "id",
                    id,
                    "team_id",
                    workspaceId,
                    "name",
                    value("name"),
                    "real_name",
                    value("real_name"),
                    "profile",
                    profile,
                    "deleted",
                    lifecycle == Lifecycle.DEACTIVATED || lifecycle == Lifecycle.REMOVED || !accountActive,
                    "is_bot",
                    flag("is_bot"),
                    "is_admin",
                    flag("is_admin"),
                    "is_owner",
                    flag("is_owner"),
                    "is_primary_owner",
                    flag("is_primary_owner"),
                    "is_restricted",
                    flag("is_restricted"),
                    "is_ultra_restricted",
                    flag("is_ultra_restricted"),
                    "is_invited_user",
                    lifecycle == Lifecycle.INVITED,
                    "updated",
                    updated);
        }
    }

    static final class Channel {
        final String id;
        final String name;
        final String creator;
        final boolean privateChannel;
        final boolean archived;
        final boolean general;
        final long created;
        final Set<String> members = new LinkedHashSet<>();

        Channel(String id, JsonNode input, long time) {
            this.id = id;
            name = required(input, "name");
            if (!name.matches("[a-z0-9_-]{1,80}")) {
                throw new ApiException("invalid_name");
            }
            creator = required(input, "creator");
            privateChannel = bool(input, "is_private", false);
            archived = bool(input, "is_archived", false);
            general = bool(input, "is_general", false);
            created = time;
            members.addAll(strings(input.path("members")));
        }

        ObjectNode slack(String caller) {
            return object(
                    "id",
                    id,
                    "name",
                    name,
                    "name_normalized",
                    name,
                    "creator",
                    creator,
                    "created",
                    created,
                    "is_channel",
                    true,
                    "is_group",
                    false,
                    "is_im",
                    false,
                    "is_mpim",
                    false,
                    "is_private",
                    privateChannel,
                    "is_archived",
                    archived,
                    "is_general",
                    general,
                    "is_member",
                    members.contains(caller),
                    "num_members",
                    members.size());
        }
    }

    static final class Invitation {
        final String id;
        final String userId;
        final List<String> channels;
        final String message;
        String status = "PENDING";

        Invitation(String id, String userId, List<String> channels, String message) {
            this.id = id;
            this.userId = userId;
            this.channels = List.copyOf(channels);
            this.message = message;
        }

        ObjectNode json() {
            return object(
                    "id", id, "userId", userId, "channelIds", channels, "status", status, "custom_message", message);
        }
    }

    static final class Workspace {
        final String id;
        final String name;
        final String url;
        Plan plan;
        final Map<String, User> users = new LinkedHashMap<>();
        final Map<String, Channel> channels = new LinkedHashMap<>();
        final Map<String, Invitation> invitations = new LinkedHashMap<>();

        Workspace(JsonNode input) {
            id = identifier(required(input, "id"), "T");
            name = required(input, "name");
            url = text(input, "url", "http://mini-slack.local");
            plan = plan(text(input, "plan", "FREE"));
        }
    }

    record Token(
            String id,
            String value,
            String workspaceId,
            String principalId,
            String type,
            Set<String> scopes,
            boolean orgLevel,
            boolean revoked,
            long expiresAt) {}

    record Context(Workspace workspace, User principal, Token token) {
        void scope(String scope) {
            if (!token.scopes().contains(scope)) {
                throw new ApiException(403, "missing_scope");
            }
        }

        void anyScope(String... scopes) {
            for (String scope : scopes) {
                if (token.scopes().contains(scope)) {
                    return;
                }
            }
            throw new ApiException(403, "missing_scope");
        }

        void userToken() {
            if (!token.type().equals("user")) {
                throw new ApiException(403, "not_allowed_token_type");
            }
        }

        void admin() {
            userToken();
            if (principal.rank() < 1) {
                throw new ApiException(403, "not_an_admin");
            }
        }
    }

    final Map<String, Workspace> workspaces = new LinkedHashMap<>();
    final Map<String, Token> tokens = new LinkedHashMap<>();
    final List<ObjectNode> audit = new ArrayList<>();
    final Clock clock;
    private long sequence;
    private long timestamp = 1_700_000_000;
    long generation;

    SlackState(Clock clock) {
        this.clock = clock;
    }

    void reset() {
        workspaces.clear();
        tokens.clear();
        audit.clear();
        sequence = 0;
        timestamp = 1_700_000_000;
        generation++;
    }

    void replace(SlackState candidate) {
        reset();
        workspaces.putAll(candidate.workspaces);
        tokens.putAll(candidate.tokens);
        audit.addAll(candidate.audit);
        sequence = candidate.sequence;
        timestamp = candidate.timestamp;
    }

    long tick() {
        return timestamp++;
    }

    String next(String prefix) {
        return String.format(Locale.ROOT, "%s%09d", prefix, ++sequence);
    }

    void event(String workspace, String action, String subject) {
        audit.add(object("timestamp", tick(), "workspaceId", workspace, "action", action, "subjectId", subject));
        if (audit.size() > 10000) {
            audit.removeFirst();
        }
    }

    Workspace workspace(String id) {
        Workspace workspace = workspaces.get(id);
        if (workspace == null) {
            throw new ApiException(404, "team_not_found");
        }
        return workspace;
    }

    Workspace createWorkspace(JsonNode input) {
        Workspace workspace = new Workspace(input);
        if (workspaces.containsKey(workspace.id)) {
            throw new ApiException(409, "workspace_exists");
        }
        workspaces.put(workspace.id, workspace);
        event(workspace.id, "workspace.created", workspace.id);
        return workspace;
    }

    User user(Workspace workspace, String id) {
        User user = workspace.users.get(id);
        if (user == null) {
            throw new ApiException(404, "user_not_found");
        }
        return user;
    }

    User createUser(Workspace workspace, JsonNode input) {
        if (!input.isObject()) {
            throw new ApiException("invalid_arguments");
        }
        ObjectNode attributes = ((ObjectNode) input).deepCopy();
        String id = identifier(text(input, "id", next("U")), "UW");
        if (workspace.users.containsKey(id)) {
            throw new ApiException(409, "user_exists");
        }
        validateAttributes(workspace, id, attributes);
        if (!attributes.has("name")) {
            attributes.put("name", id.toLowerCase(Locale.ROOT));
        }
        User user = new User(id, attributes, tick());
        workspace.users.put(id, user);
        event(workspace.id, "user.created", id);
        return user;
    }

    void validateAttributes(Workspace workspace, String id, ObjectNode attributes) {
        for (String flag : List.of(
                "is_bot",
                "is_admin",
                "is_owner",
                "is_primary_owner",
                "is_restricted",
                "is_ultra_restricted",
                "accountActive")) {
            if (attributes.has(flag)) {
                attributes.put(flag, bool(attributes, flag, false));
            }
        }
        if (attributes.hasNonNull("email")) {
            String email = email(required(attributes, "email"));
            attributes.put("email", email);
            if (workspace.users.values().stream()
                    .anyMatch(u -> !u.id.equals(id) && u.value("email").equals(email))) {
                throw new ApiException(409, "email_taken");
            }
        }
        if (bool(attributes, "is_primary_owner", false)) {
            if (workspace.users.values().stream()
                    .anyMatch(user -> !user.id.equals(id) && user.flag("is_primary_owner"))) {
                throw new ApiException(409, "primary_owner_exists");
            }
            attributes.put("is_owner", true);
        }
        if (bool(attributes, "is_owner", false)) {
            attributes.put("is_admin", true);
        }
        if (bool(attributes, "is_ultra_restricted", false)) {
            attributes.put("is_restricted", true);
        }
        if (bool(attributes, "is_bot", false) && bool(attributes, "is_admin", false)) {
            throw new ApiException("invalid_arguments");
        }
        lifecycle(text(attributes, "state", "ACTIVE"));
    }

    void updateUser(Workspace workspace, User user, JsonNode patch) {
        ObjectNode updated = user.attributes.deepCopy();
        patch.properties().forEach(entry -> updated.set(entry.getKey(), entry.getValue()));
        validateAttributes(workspace, user.id, updated);
        Lifecycle state = patch.has("state") ? lifecycle(required(patch, "state")) : user.lifecycle;
        user.attributes = updated;
        if (patch.has("state")) {
            transition(workspace, user, state);
        }
        user.updated = tick();
        event(workspace.id, "user.updated", user.id);
    }

    void transition(Workspace workspace, User user, Lifecycle state) {
        user.lifecycle = state;
        if (state != Lifecycle.REMOVED) {
            user.accountActive = state != Lifecycle.DEACTIVATED;
        }
        if (state == Lifecycle.DEACTIVATED || state == Lifecycle.REMOVED) {
            workspace.channels.values().forEach(channel -> channel.members.remove(user.id));
        }
        user.updated = tick();
        event(workspace.id, "user." + state.name().toLowerCase(Locale.ROOT), user.id);
    }

    void accountActive(Workspace workspace, User user, boolean active) {
        if (user.lifecycle != Lifecycle.REMOVED) {
            transition(workspace, user, active ? Lifecycle.ACTIVE : Lifecycle.DEACTIVATED);
        }
        user.accountActive = active;
        user.updated = tick();
        event(workspace.id, active ? "account.activated" : "account.deactivated", user.id);
    }

    Channel createChannel(Workspace workspace, JsonNode input) {
        Channel channel = new Channel(identifier(text(input, "id", next("C")), "CG"), input, tick());
        if (workspace.channels.containsKey(channel.id)
                || workspace.channels.values().stream().anyMatch(c -> c.name.equals(channel.name))) {
            throw new ApiException(409, "name_taken");
        }
        user(workspace, channel.creator);
        for (String member : channel.members) {
            if (!user(workspace, member).active()) {
                throw new ApiException("user_disabled");
            }
        }
        workspace.channels.put(channel.id, channel);
        event(workspace.id, "channel.created", channel.id);
        return channel;
    }

    Invitation invite(Workspace workspace, JsonNode input) {
        String email = email(required(input, "email"));
        User existing = workspace.users.values().stream()
                .filter(u -> u.value("email").equals(email))
                .findFirst()
                .orElse(null);
        if (existing != null && existing.lifecycle == Lifecycle.INVITED) {
            throw new ApiException(409, "already_in_team_invited_user");
        }
        if (existing != null && existing.active()) {
            throw new ApiException(409, "already_in_team");
        }
        List<String> channels = invitationChannels(workspace, input);
        User invited;
        if (existing != null) {
            invited = existing;
            transition(workspace, invited, Lifecycle.INVITED);
        } else {
            ObjectNode attrs = object(
                    "email",
                    email,
                    "real_name",
                    text(input, "real_name", ""),
                    "state",
                    "INVITED",
                    "is_restricted",
                    bool(input, "is_restricted", false),
                    "is_ultra_restricted",
                    bool(input, "is_ultra_restricted", false));
            invited = createUser(workspace, attrs);
        }
        Invitation invitation = new Invitation(next("I"), invited.id, channels, text(input, "custom_message", ""));
        workspace.invitations.put(invitation.id, invitation);
        event(workspace.id, "invitation.created", invitation.id);
        return invitation;
    }

    void adminInvite(Workspace workspace, JsonNode input) {
        String email = email(required(input, "email"));
        User existing = workspace.users.values().stream()
                .filter(user -> user.value("email").equals(email))
                .findFirst()
                .orElse(null);
        if (existing != null && !existing.accountActive) {
            List<String> channels = invitationChannels(workspace, input);
            transition(workspace, existing, Lifecycle.ACTIVE);
            for (String channelId : channels) {
                Channel channel = workspace.channels.get(channelId);
                if (channel != null) {
                    channel.members.add(existing.id);
                }
            }
            return;
        }
        invite(workspace, input);
    }

    private static List<String> invitationChannels(Workspace workspace, JsonNode input) {
        List<String> channels = strings(input.path("channel_ids"));
        if (channels.isEmpty()) {
            throw new ApiException("failed_to_validate_channels");
        }
        for (String id : channels) {
            Channel channel = workspace.channels.get(id);
            if (channel == null || channel.archived) {
                throw new ApiException("failed_to_validate_channels");
            }
        }
        if (bool(input, "is_ultra_restricted", false) && channels.size() != 1) {
            throw new ApiException("failed_to_validate_channels");
        }
        return channels;
    }

    Invitation resolveInvitation(Workspace workspace, String id, boolean accept) {
        Invitation invitation = workspace.invitations.get(id);
        if (invitation == null) {
            throw new ApiException(404, "invitation_not_found");
        }
        if (!invitation.status.equals("PENDING")) {
            throw new ApiException(409, "invitation_resolved");
        }
        User user = user(workspace, invitation.userId);
        if (user.lifecycle != Lifecycle.INVITED) {
            throw new ApiException(409, "invitation_invalid_state");
        }
        List<Channel> invitationChannels = new ArrayList<>();
        for (String channelId : invitation.channels) {
            Channel channel = workspace.channels.get(channelId);
            if (channel == null || channel.archived) {
                throw new ApiException(409, "invitation_invalid_channel");
            }
            invitationChannels.add(channel);
        }
        invitation.status = accept ? "ACCEPTED" : "REJECTED";
        transition(workspace, user, accept ? Lifecycle.ACTIVE : Lifecycle.REMOVED);
        if (accept) {
            invitationChannels.forEach(channel -> channel.members.add(user.id));
        }
        event(workspace.id, accept ? "invitation.accepted" : "invitation.rejected", id);
        return invitation;
    }

    Token createToken(JsonNode input) {
        Workspace workspace = workspace(required(input, "workspaceId"));
        User principal = user(workspace, required(input, "principalId"));
        String type = text(input, "type", principal.flag("is_bot") ? "bot" : "user");
        if (!Set.of("bot", "user").contains(type) || type.equals("bot") != principal.flag("is_bot")) {
            throw new ApiException("invalid_token_context");
        }
        String id = next("TOKEN");
        String value = text(input, "token", (type.equals("bot") ? "xoxb" : "xoxp") + "-mini-" + id);
        if (!value.matches((type.equals("bot") ? "xoxb" : "xoxp") + "-mini-[A-Za-z0-9_-]{4,200}")) {
            throw new ApiException("synthetic_token_required");
        }
        if (tokens.containsKey(value)) {
            throw new ApiException(409, "token_exists");
        }
        long expiresAt = input.path("expiresAt").asLong(0);
        Token token = new Token(
                id,
                value,
                workspace.id,
                principal.id,
                type,
                Set.copyOf(strings(input.path("scopes"))),
                bool(input, "orgLevel", false),
                bool(input, "revoked", false),
                expiresAt);
        tokens.put(value, token);
        event(workspace.id, "token.created", id);
        return token;
    }

    Context authenticate(String bearer, JsonNode parameters) {
        if (bearer.isEmpty()) {
            throw new ApiException(401, "not_authed");
        }
        Token token = tokens.get(bearer);
        if (token == null) {
            throw new ApiException(401, "invalid_auth");
        }
        if (token.revoked()) {
            throw new ApiException(401, "token_revoked");
        }
        if (token.expiresAt() > 0 && token.expiresAt() <= clock.instant().getEpochSecond()) {
            throw new ApiException(401, "token_expired");
        }
        Workspace workspace = workspace(token.workspaceId());
        User user = user(workspace, token.principalId());
        if (!user.active()) {
            throw new ApiException(401, "account_inactive");
        }
        if (token.orgLevel()
                && parameters.has("team_id")
                && !text(parameters, "team_id", "").equals(workspace.id)) {
            throw new ApiException(403, "team_access_not_granted");
        }
        return new Context(workspace, user, token);
    }

    ObjectNode snapshot() {
        List<ObjectNode> entries = new ArrayList<>();
        for (Workspace workspace : workspaces.values()) {
            List<ObjectNode> users = workspace.users.values().stream()
                    .map(u -> object(
                            "id",
                            u.id,
                            "state",
                            u.lifecycle.name(),
                            "accountActive",
                            u.accountActive,
                            "created",
                            u.created,
                            "updated",
                            u.updated,
                            "profile",
                            u.slack(workspace.id, true)))
                    .toList();
            entries.add(object(
                    "id",
                    workspace.id,
                    "name",
                    workspace.name,
                    "url",
                    workspace.url,
                    "plan",
                    workspace.plan.name(),
                    "users",
                    users,
                    "channels",
                    workspace.channels.values().stream()
                            .map(c -> {
                                ObjectNode json = c.slack("");
                                json.set("members", array(c.members));
                                return json;
                            })
                            .toList(),
                    "invitations",
                    workspace.invitations.values().stream()
                            .map(Invitation::json)
                            .toList()));
        }
        return object(
                "workspaces",
                entries,
                "tokens",
                tokens.values().stream()
                        .map(t -> object(
                                "id",
                                t.id(),
                                "workspaceId",
                                t.workspaceId(),
                                "principalId",
                                t.principalId(),
                                "type",
                                t.type(),
                                "scopes",
                                t.scopes(),
                                "orgLevel",
                                t.orgLevel(),
                                "revoked",
                                t.revoked(),
                                "expiresAt",
                                t.expiresAt()))
                        .toList(),
                "events",
                audit);
    }

    static Plan plan(String value) {
        try {
            return Plan.valueOf(value);
        } catch (IllegalArgumentException exception) {
            throw new ApiException("invalid_plan");
        }
    }

    static Lifecycle lifecycle(String value) {
        try {
            return Lifecycle.valueOf(value);
        } catch (IllegalArgumentException exception) {
            throw new ApiException("invalid_state");
        }
    }

    static String identifier(String id, String prefixes) {
        if (!id.matches("[" + prefixes + "][A-Z0-9]{3,40}")) {
            throw new ApiException("invalid_id");
        }
        return id;
    }
}
