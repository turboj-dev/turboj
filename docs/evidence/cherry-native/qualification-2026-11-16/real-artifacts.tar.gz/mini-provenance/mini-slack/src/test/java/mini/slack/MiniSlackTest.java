package mini.slack;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
@Test
@Tag("mini-slack")
@ExtendWith(MiniSlackExtension.class)
public @interface MiniSlackTest {
    String fixture() default "empty";

    Plan plan() default Plan.FREE;

    String project() default "mini_slack";
}
