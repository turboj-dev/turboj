package mini.slack;

import static mini.slack.Json.*;
import static org.assertj.core.api.Assertions.assertThat;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.file.Path;
import java.time.Duration;
import java.util.HashSet;
import java.util.Set;
import org.junit.jupiter.api.Test;
import tools.jackson.databind.JsonNode;
import tools.jackson.databind.node.ObjectNode;

class ContainerContract {
    @Test
    void mini_slack_project_container_suite_workspace_lifecycle_test() throws Exception {
        String endpoint = System.getenv()
                .getOrDefault(
                        "MINI_SLACK_CONTAINER_URL",
                        System.getenv().getOrDefault("CHERRY_TEST_MINI_SLACK_SLACK_URL", ""));
        assertThat(endpoint)
                .as("A running Mini-Slack endpoint is required by -Pcontainer")
                .isNotBlank();
        URI base = URI.create(endpoint);
        SlackEndpoints.forEnvironment("test", URI.create(base + "/api"), URI.create(base + "/scim/v2"));
        String secret = System.getenv().getOrDefault("MINI_SLACK_TEST_SECRET", "");
        assertThat(secret).hasSizeGreaterThanOrEqualTo(32);
        boolean passed = false;
        try (HttpClient client = HttpClient.newBuilder()
                .followRedirects(HttpClient.Redirect.NEVER)
                .build()) {
            try {
                assertThat(call(client, base, "GET", "/health", object(), "", "")
                                .path("simulator")
                                .asString())
                        .isEqualTo("mini-slack");
                call(client, base, "POST", "/_test/seed", Fixtures.load("large"), "", secret);
                String token = call(
                                client,
                                base,
                                "POST",
                                "/_test/tokens",
                                object(
                                        "workspaceId",
                                        HttpFixture.WORKSPACE,
                                        "principalId",
                                        "UADMIN0001",
                                        "scopes",
                                        HttpFixture.SCOPES,
                                        "orgLevel",
                                        true),
                                "",
                                secret)
                        .path("token")
                        .asString();
                assertThat(call(client, base, "POST", "/api/auth.test", object(), token, "")
                                .path("ok")
                                .asBoolean())
                        .isTrue();
                JsonNode forbidden = call(
                        client,
                        base,
                        "POST",
                        "/api/admin.users.invite",
                        object(
                                "team_id",
                                HttpFixture.WORKSPACE,
                                "email",
                                "container@example.test",
                                "channel_ids",
                                "CLOCAL0001"),
                        token,
                        "");
                assertThat(forbidden.path("error").asString()).isEqualTo("feature_not_enabled");
                Set<String> ids = new HashSet<>();
                String cursor = "";
                do {
                    JsonNode page = call(
                            client, base, "GET", "/api/users.list?limit=100&cursor=" + cursor, object(), token, "");
                    for (JsonNode user : page.path("members")) {
                        assertThat(ids.add(user.path("id").asString())).isTrue();
                    }
                    cursor = page.path("response_metadata").path("next_cursor").asString();
                } while (!cursor.isEmpty());
                assertThat(ids).hasSize(1003);
                JsonNode invite = call(
                        client,
                        base,
                        "POST",
                        "/_test/invitations",
                        object(
                                "workspaceId",
                                HttpFixture.WORKSPACE,
                                "email",
                                "container@example.test",
                                "channel_ids",
                                "CLOCAL0001"),
                        "",
                        secret);
                call(
                        client,
                        base,
                        "POST",
                        "/_test/invitations/" + invite.path("id").asString() + "/accept",
                        object("workspaceId", HttpFixture.WORKSPACE),
                        "",
                        secret);
                JsonNode active = call(
                        client,
                        base,
                        "GET",
                        "/api/users.lookupByEmail?email=container%40example.test",
                        object(),
                        token,
                        "");
                assertThat(active.path("user").path("deleted").asBoolean()).isFalse();
                call(
                        client,
                        base,
                        "POST",
                        "/_test/users/" + active.path("user").path("id").asString() + "/deactivate",
                        object("workspaceId", HttpFixture.WORKSPACE),
                        "",
                        secret);
                assertThat(call(
                                        client,
                                        base,
                                        "GET",
                                        "/api/users.lookupByEmail?email=container%40example.test",
                                        object(),
                                        token,
                                        "")
                                .path("error")
                                .asString())
                        .isEqualTo("users_not_found");
                passed = true;
            } finally {
                Evidence evidence = new Evidence();
                for (JsonNode record : call(client, base, "GET", "/_test/requests", object(), "", secret)) {
                    evidence.add((ObjectNode) record);
                }
                evidence.report(
                        Path.of(System.getenv().getOrDefault("CHERRY_TEST_REPORT_DIR", "target/cherry-test/reports")),
                        "mini-slack",
                        "mini_slack_project_container_suite_workspace_lifecycle_test",
                        passed,
                        passed ? "" : "Container contract failed; see JUnit assertion",
                        base.toString());
            }
        }
    }

    private static JsonNode call(
            HttpClient client, URI base, String method, String path, JsonNode body, String token, String secret)
            throws Exception {
        HttpRequest.Builder builder = HttpRequest.newBuilder(base.resolve(path))
                .timeout(Duration.ofSeconds(5))
                .header("Content-Type", "application/json");
        if (!token.isEmpty()) {
            builder.header("Authorization", "Bearer " + token);
        }
        if (!secret.isEmpty()) {
            builder.header("X-Mini-Slack-Secret", secret);
        }
        HttpResponse<String> response = client.send(
                builder.method(
                                method,
                                method.equals("GET")
                                        ? HttpRequest.BodyPublishers.noBody()
                                        : HttpRequest.BodyPublishers.ofString(body.toString()))
                        .build(),
                HttpResponse.BodyHandlers.ofString());
        assertThat(response.statusCode()).isEqualTo(200);
        return MAPPER.readTree(response.body());
    }
}
