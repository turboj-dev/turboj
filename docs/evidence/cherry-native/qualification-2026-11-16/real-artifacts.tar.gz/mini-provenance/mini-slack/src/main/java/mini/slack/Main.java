package mini.slack;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Clock;
import java.time.Duration;
import java.util.Map;
import java.util.concurrent.CountDownLatch;

public final class Main {
    private Main() {}

    public static void main(String[] args) throws Exception {
        Map<String, String> env = System.getenv();
        int port = Integer.parseInt(env.getOrDefault("MINI_SLACK_PORT", "0"));
        if (args.length == 1 && args[0].equals("health")) {
            try (HttpClient client = HttpClient.newBuilder()
                    .connectTimeout(Duration.ofSeconds(2))
                    .build()) {
                HttpResponse<Void> response = client.send(
                        HttpRequest.newBuilder(URI.create("http://127.0.0.1:" + port + "/health"))
                                .timeout(Duration.ofSeconds(2))
                                .GET()
                                .build(),
                        HttpResponse.BodyHandlers.discarding());
                if (response.statusCode() != 200) {
                    throw new IllegalStateException("Mini-Slack health check failed");
                }
            }
            return;
        }
        if (args.length != 0) {
            throw new IllegalArgumentException("Usage: java -jar mini-slack.jar [health]");
        }
        MiniSlackServer.Settings settings = new MiniSlackServer.Settings(
                env.getOrDefault("MINI_SLACK_BIND", "127.0.0.1"),
                port,
                env.getOrDefault("MINI_SLACK_ENV", "test"),
                Boolean.parseBoolean(env.getOrDefault("MINI_SLACK_CONTAINER", "false")),
                Boolean.parseBoolean(env.getOrDefault("MINI_SLACK_TEST_API", "false")),
                env.getOrDefault("MINI_SLACK_TEST_SECRET", ""));
        String fixture = env.getOrDefault("MINI_SLACK_FIXTURE", "");
        MiniSlackServer server = new MiniSlackServer(
                settings,
                Clock.systemUTC(),
                fixture.isBlank() ? null : Json.MAPPER.readTree(Files.readString(Path.of(fixture))));
        try {
            String endpointFile = env.getOrDefault("MINI_SLACK_ENDPOINT_FILE", "");
            if (!endpointFile.isBlank()) {
                Files.writeString(
                        Path.of(endpointFile),
                        Json.MAPPER.writeValueAsString(server.environment("mini_slack", "slack")));
            }
            CountDownLatch done = new CountDownLatch(1);
            Runtime.getRuntime()
                    .addShutdownHook(new Thread(
                            () -> {
                                server.close();
                                done.countDown();
                            },
                            "mini-slack-shutdown"));
            done.await();
        } finally {
            server.close();
        }
    }
}
