package mini.slack;

import static mini.slack.Json.*;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import mini.slack.SlackState.Channel;
import mini.slack.SlackState.Context;
import mini.slack.SlackState.Lifecycle;
import mini.slack.SlackState.User;
import tools.jackson.databind.JsonNode;
import tools.jackson.databind.node.ObjectNode;

final class WebApi {
    private final SlackState state;

    WebApi(SlackState state) {
        this.state = state;
    }

    ObjectNode call(String method, String verb, String bearer, JsonNode input) {
        boolean write = Set.of(
                        "auth.test",
                        "conversations.invite",
                        "conversations.kick",
                        "admin.users.invite",
                        "admin.users.remove")
                .contains(method);
        if (!(verb.equals("POST") || (!write && verb.equals("GET")))) {
            throw new ApiException("unknown_method");
        }
        Context context = state.authenticate(bearer, input);
        return switch (method) {
            case "auth.test" -> auth(context);
            case "users.list" -> users(context, input);
            case "users.info" -> userInfo(context, input);
            case "users.lookupByEmail" -> lookup(context, input);
            case "conversations.list" -> channels(context, input);
            case "conversations.info", "conversations.members", "conversations.invite", "conversations.kick" ->
                channel(method, context, input);
            case "admin.users.invite", "admin.users.remove" -> admin(method, context, input);
            default -> throw new ApiException("unknown_method");
        };
    }

    private static ObjectNode auth(Context c) {
        ObjectNode response = object(
                "ok",
                true,
                "team",
                c.workspace().name,
                "team_id",
                c.workspace().id,
                "url",
                c.workspace().url,
                "user",
                c.principal().value("name"),
                "user_id",
                c.principal().id);
        if (c.token().type().equals("bot")) {
            response.put("bot_id", "B" + c.principal().id.substring(1));
        }
        return response;
    }

    private ObjectNode users(Context c, JsonNode input) {
        c.scope("users:read");
        List<ObjectNode> users = c.workspace().users.values().stream()
                .filter(u -> u.lifecycle != Lifecycle.REMOVED)
                .sorted(Comparator.comparing(u -> u.id))
                .map(u -> u.slack(c.workspace().id, c.token().scopes().contains("users:read.email")))
                .toList();
        ObjectNode result = page(c, "users.list", input, "members", users);
        result.put("cache_ts", 1700000000);
        return result;
    }

    private ObjectNode userInfo(Context c, JsonNode input) {
        c.scope("users:read");
        User user = state.user(c.workspace(), required(input, "user"));
        if (user.lifecycle == Lifecycle.REMOVED) {
            throw new ApiException("user_not_found");
        }
        return object(
                "ok",
                true,
                "user",
                user.slack(c.workspace().id, c.token().scopes().contains("users:read.email")));
    }

    private static ObjectNode lookup(Context c, JsonNode input) {
        c.scope("users:read.email");
        String email = email(required(input, "email"));
        User user = c.workspace().users.values().stream()
                .filter(u -> u.active() && u.value("email").equals(email))
                .findFirst()
                .orElseThrow(() -> new ApiException("users_not_found"));
        return object("ok", true, "user", user.slack(c.workspace().id, true));
    }

    private ObjectNode channels(Context c, JsonNode input) {
        List<String> types = strings(input.has("types") ? input.path("types") : MAPPER.valueToTree("public_channel"));
        if (types.isEmpty()
                || types.stream()
                        .anyMatch(t ->
                                !Set.of("public_channel", "private_channel").contains(t))) {
            throw new ApiException("invalid_types");
        }
        c.anyScope(types.stream()
                .map(t -> t.equals("public_channel") ? "channels:read" : "groups:read")
                .toArray(String[]::new));
        List<ObjectNode> channels = c.workspace().channels.values().stream()
                .filter(ch -> types.contains(ch.privateChannel ? "private_channel" : "public_channel"))
                .filter(ch -> c.token().scopes().contains(ch.privateChannel ? "groups:read" : "channels:read"))
                .filter(ch -> !ch.privateChannel || ch.members.contains(c.principal().id))
                .filter(ch -> !bool(input, "exclude_archived", false) || !ch.archived)
                .sorted(Comparator.comparing(ch -> ch.id))
                .map(ch -> ch.slack(c.principal().id))
                .toList();
        return page(
                c,
                "conversations.list:" + String.join(",", types) + ":" + bool(input, "exclude_archived", false),
                input,
                "channels",
                channels);
    }

    private ObjectNode channel(String method, Context c, JsonNode input) {
        Channel channel = c.workspace().channels.get(required(input, "channel"));
        if (channel == null || (channel.privateChannel && !channel.members.contains(c.principal().id))) {
            throw new ApiException("channel_not_found");
        }
        boolean mutate = method.equals("conversations.invite") || method.equals("conversations.kick");
        if (!mutate) {
            c.scope(channel.privateChannel ? "groups:read" : "channels:read");
            if (method.equals("conversations.info")) {
                return object("ok", true, "channel", channel.slack(c.principal().id));
            }
            return page(
                    c,
                    "conversations.members:" + channel.id,
                    input,
                    "members",
                    channel.members.stream().sorted().toList());
        }
        String broadScope = channel.privateChannel
                ? "groups:write"
                : c.token().type().equals("bot") ? "channels:manage" : "channels:write";
        if (method.equals("conversations.invite")) {
            c.anyScope(broadScope, channel.privateChannel ? "groups:write.invites" : "channels:write.invites");
        } else {
            c.scope(broadScope);
        }
        if (!channel.members.contains(c.principal().id)) {
            throw new ApiException("not_in_channel");
        }
        if (channel.archived) {
            throw new ApiException("is_archived");
        }
        if (c.principal().flag("is_restricted")) {
            throw new ApiException("restricted_action");
        }
        if (method.equals("conversations.kick")) {
            String userId = required(input, "user");
            state.user(c.workspace(), userId);
            if (userId.equals(c.principal().id)) {
                throw new ApiException("cant_kick_self");
            }
            if (channel.general) {
                throw new ApiException("cant_kick_from_general");
            }
            if (!channel.members.remove(userId)) {
                throw new ApiException("not_in_channel");
            }
            state.event(c.workspace().id, "channel.kicked", userId);
            return object("ok", true, "errors", object());
        }
        List<String> ids = strings(input.path("users"));
        if (ids.isEmpty() || ids.size() > 1000) {
            throw new ApiException("invalid_arguments");
        }
        List<ObjectNode> errors = new ArrayList<>();
        List<String> valid = new ArrayList<>();
        for (String id : new LinkedHashSet<>(ids)) {
            User user = c.workspace().users.get(id);
            String error = user == null
                    ? "user_not_found"
                    : !user.active()
                            ? "user_not_found"
                            : id.equals(c.principal().id)
                                    ? "cant_invite_self"
                                    : channel.members.contains(id) ? "already_in_channel" : "";
            if (!error.isEmpty()) {
                errors.add(object("user", id, "ok", false, "error", error));
            } else {
                valid.add(id);
            }
        }
        if (errors.isEmpty() || (bool(input, "force", false) && ids.size() > 1)) {
            channel.members.addAll(valid);
            valid.forEach(id -> state.event(c.workspace().id, "channel.invited", id));
        }
        if (!errors.isEmpty()) {
            return object("ok", false, "error", errors.getFirst().path("error").asString(), "errors", errors);
        }
        return object("ok", true, "channel", channel.slack(c.principal().id));
    }

    private ObjectNode admin(String method, Context c, JsonNode input) {
        if (c.workspace().plan != Plan.ENTERPRISE) {
            throw new ApiException("feature_not_enabled");
        }
        c.userToken();
        c.scope("admin.users:write");
        c.admin();
        if (!c.token().orgLevel()) {
            throw new ApiException("not_allowed_token_type");
        }
        if (!required(input, "team_id").equals(c.workspace().id)) {
            throw new ApiException("team_access_not_granted");
        }
        if (method.equals("admin.users.invite")) {
            if (input.has("guest_expiration_ts")) {
                throw new ApiException("failed_to_validate_expiration");
            }
            if (bool(input, "resend", false) || bool(input, "email_password_policy_enabled", false)) {
                throw new ApiException("invalid_arguments");
            }
            state.adminInvite(c.workspace(), input);
        } else {
            User user = state.user(c.workspace(), required(input, "user_id"));
            if (user.flag("is_primary_owner")) {
                throw new ApiException("cannot_modify_primary_owner");
            }
            if (user.rank() > c.principal().rank()) {
                throw new ApiException("not_an_admin");
            }
            if (user.lifecycle == Lifecycle.REMOVED) {
                throw new ApiException("user_not_found");
            }
            state.transition(c.workspace(), user, Lifecycle.REMOVED);
        }
        return object("ok", true);
    }

    private ObjectNode page(Context c, String method, JsonNode input, String field, List<?> values) {
        int limit = integer(input, "limit", 100, 1, 1000);
        String cursor = text(input, "cursor", "");
        String prefix =
                state.generation + ":" + c.workspace().id + ":" + c.token().id() + ":" + method + ":";
        int start = 0;
        if (!cursor.isEmpty()) {
            try {
                String decoded = new String(Base64.getUrlDecoder().decode(cursor), StandardCharsets.UTF_8);
                if (!decoded.startsWith(prefix)) {
                    throw new ApiException("invalid_cursor");
                }
                start = Integer.parseInt(decoded.substring(prefix.length()));
                if (start < 0 || start >= values.size()) {
                    throw new ApiException("invalid_cursor");
                }
            } catch (IllegalArgumentException exception) {
                throw new ApiException("invalid_cursor");
            }
        }
        int end = Math.min(start + limit, values.size());
        String next = end < values.size()
                ? Base64.getUrlEncoder()
                        .withoutPadding()
                        .encodeToString((prefix + end).getBytes(StandardCharsets.UTF_8))
                : "";
        return object("ok", true, field, values.subList(start, end), "response_metadata", object("next_cursor", next));
    }
}
