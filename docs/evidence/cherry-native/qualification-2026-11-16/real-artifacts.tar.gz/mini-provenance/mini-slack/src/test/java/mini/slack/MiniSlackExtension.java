package mini.slack;

import java.io.IOException;
import java.lang.reflect.Method;
import java.nio.file.Path;
import java.util.List;
import java.util.Locale;
import org.jspecify.annotations.Nullable;
import org.junit.jupiter.api.extension.AfterEachCallback;
import org.junit.jupiter.api.extension.BeforeEachCallback;
import org.junit.jupiter.api.extension.ExtensionContext;
import org.junit.jupiter.api.extension.InvocationInterceptor;
import org.junit.jupiter.api.extension.ParameterContext;
import org.junit.jupiter.api.extension.ParameterResolver;
import org.junit.jupiter.api.extension.ReflectiveInvocationContext;
import org.opentest4j.TestAbortedException;
import tools.jackson.databind.node.ObjectNode;

public final class MiniSlackExtension
        implements BeforeEachCallback, AfterEachCallback, ParameterResolver, InvocationInterceptor {
    private static final ExtensionContext.Namespace NAMESPACE =
            ExtensionContext.Namespace.create(MiniSlackExtension.class);

    @Override
    public void beforeEach(ExtensionContext context) throws Exception {
        MiniSlackTest settings = context.getRequiredTestMethod().getAnnotation(MiniSlackTest.class);
        MiniSlackServer server = MiniSlackServer.local();
        context.getStore(NAMESPACE).put(MiniSlackServer.class, server);
        ObjectNode fixture = (ObjectNode) Fixtures.load(settings.fixture());
        fixture.put("plan", settings.plan().name());
        server.seed(fixture);
    }

    @Override
    public void interceptTestMethod(
            Invocation<@Nullable Void> invocation, ReflectiveInvocationContext<Method> method, ExtensionContext context)
            throws Throwable {
        try {
            invocation.proceed();
        } catch (TestAbortedException aborted) {
            throw aborted;
        } catch (Throwable failure) {
            MiniSlackServer server = context.getStore(NAMESPACE).get(MiniSlackServer.class, MiniSlackServer.class);
            if (server == null) {
                throw failure;
            }
            List<ObjectNode> requests = server.requests();
            StringBuilder message = new StringBuilder(failure.getClass().getSimpleName())
                    .append(": ")
                    .append(failure.getMessage())
                    .append("\nMini-Slack scenario: ")
                    .append(context.getRequiredTestMethod().getName());
            for (ObjectNode request : requests.subList(Math.max(0, requests.size() - 3), requests.size())) {
                String detail = request.toString();
                message.append("\nHTTP evidence: ")
                        .append(detail.length() > 8000 ? detail.substring(0, 8000) + " [truncated]" : detail);
            }
            String sanitized = Evidence.scrubText(message.toString());
            if (!server.testSecret().isEmpty()) {
                sanitized = sanitized.replace(server.testSecret(), "[REDACTED]");
            }
            AssertionError enriched = new AssertionError(sanitized);
            enriched.setStackTrace(failure.getStackTrace());
            throw enriched;
        }
    }

    @Override
    public void afterEach(ExtensionContext context) throws IOException {
        MiniSlackServer server = context.getStore(NAMESPACE).remove(MiniSlackServer.class, MiniSlackServer.class);
        if (server == null) {
            return;
        }
        server.close();
        MiniSlackTest settings = context.getRequiredTestMethod().getAnnotation(MiniSlackTest.class);
        String method = context.getRequiredTestMethod().getName();
        String fullName = method.contains("_project_") && method.contains("_suite_") && method.endsWith("_test")
                ? method
                : settings.project() + "_project_"
                        + context.getRequiredTestClass()
                                .getSimpleName()
                                .toLowerCase(Locale.ROOT)
                                .replaceAll("[^a-z0-9_]", "_")
                        + "_suite_" + method.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9_]", "_") + "_test";
        String packageName = System.getenv().getOrDefault("CHERRY_TEST_PACKAGE", "mini-slack");
        Throwable failure = context.getExecutionException().orElse(null);
        server.writeReport(
                Path.of(System.getProperty(
                        "mini.slack.reportDir",
                        System.getenv().getOrDefault("CHERRY_TEST_REPORT_DIR", "target/cherry-test/reports"))),
                packageName,
                fullName,
                failure == null,
                failure == null ? "" : failure.getClass().getSimpleName() + ": " + failure.getMessage());
    }

    @Override
    public boolean supportsParameter(ParameterContext parameter, ExtensionContext context) {
        return parameter.getParameter().getType().equals(MiniSlackServer.class);
    }

    @Override
    public Object resolveParameter(ParameterContext parameter, ExtensionContext context) {
        MiniSlackServer server = context.getStore(NAMESPACE).get(MiniSlackServer.class, MiniSlackServer.class);
        if (server == null) {
            throw new IllegalStateException("Mini-Slack lifecycle did not start");
        }
        return server;
    }
}
