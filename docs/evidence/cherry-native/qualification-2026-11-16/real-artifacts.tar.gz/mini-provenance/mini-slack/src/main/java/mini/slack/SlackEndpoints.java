package mini.slack;

import java.net.URI;
import java.util.Set;

public record SlackEndpoints(URI api, URI scim) {
    public static SlackEndpoints forEnvironment(String environment, URI api, URI scim) {
        if (environment.equals("production") || environment.equals("prod")) {
            if (!api.equals(URI.create("https://slack.com/api"))
                    || !scim.equals(URI.create("https://api.slack.com/scim/v2"))) {
                throw new IllegalArgumentException("Production Slack integration requires official endpoints");
            }
        } else if (Set.of("test", "development").contains(environment)) {
            local(api, "/api");
            local(scim, "/scim/v2");
        } else {
            throw new IllegalArgumentException("Unknown application environment");
        }
        return new SlackEndpoints(api, scim);
    }

    private static void local(URI uri, String path) {
        if (!"http".equals(uri.getScheme())
                || uri.getHost() == null
                || !Set.of("127.0.0.1", "localhost", "[::1]", "mini-slack").contains(uri.getHost())
                || !path.equals(uri.getPath())
                || uri.getUserInfo() != null
                || uri.getQuery() != null
                || uri.getFragment() != null) {
            throw new IllegalArgumentException("Mini-Slack tests require an explicit local endpoint");
        }
    }
}
