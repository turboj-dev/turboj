package mini.slack;

final class ApiException extends RuntimeException {
    private final int status;
    private final String error;

    ApiException(String error) {
        this(400, error);
    }

    ApiException(int status, String error) {
        super(error);
        this.status = status;
        this.error = error;
    }

    int status() {
        return status;
    }

    @Override
    public String getMessage() {
        return error;
    }
}
