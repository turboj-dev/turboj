package mini.slack;

import static mini.slack.Json.*;
import static org.assertj.core.api.Assertions.assertThat;

import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.List;
import tools.jackson.databind.JsonNode;

final class HttpFixture implements AutoCloseable {
    static final String WORKSPACE = "TTEST0001";
    static final List<String> SCOPES = List.of(
            "users:read",
            "users:read.email",
            "channels:read",
            "groups:read",
            "channels:write.invites",
            "channels:manage",
            "channels:write",
            "groups:write",
            "admin.users:write",
            "admin");
    final MiniSlackServer server;
    final HttpClient client = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(3))
            .followRedirects(HttpClient.Redirect.NEVER)
            .build();
    String token;

    HttpFixture(MiniSlackServer server) throws Exception {
        this.server = server;
        token = token("UADMIN0001", SCOPES, true, false, 0);
    }

    String token(String principal, List<String> scopes, boolean org, boolean revoked, long expires) throws Exception {
        return control(
                        "POST",
                        "/_test/tokens",
                        object(
                                "workspaceId",
                                WORKSPACE,
                                "principalId",
                                principal,
                                "scopes",
                                scopes,
                                "orgLevel",
                                org,
                                "revoked",
                                revoked,
                                "expiresAt",
                                expires))
                .path("token")
                .asString();
    }

    JsonNode control(String method, String path, JsonNode body) throws Exception {
        HttpResponse<String> response = raw(method, path, body, "", true, Duration.ofSeconds(5));
        assertThat(response.statusCode()).as(response.body()).isEqualTo(200);
        return MAPPER.readTree(response.body());
    }

    JsonNode api(String method, String path, JsonNode body) throws Exception {
        HttpResponse<String> response = raw(method, path, body, token, false, Duration.ofSeconds(5));
        assertThat(response.statusCode()).as(response.body()).isEqualTo(200);
        return MAPPER.readTree(response.body());
    }

    JsonNode get(String path) throws Exception {
        return api("GET", "/api/" + path, object());
    }

    JsonNode post(String method, JsonNode body) throws Exception {
        return api("POST", "/api/" + method, body);
    }

    JsonNode addUser(String email) throws Exception {
        return control("POST", "/_test/users", object("workspaceId", WORKSPACE, "email", email));
    }

    JsonNode state() throws Exception {
        return control("GET", "/_test/state", object());
    }

    void plan(Plan plan) throws Exception {
        control("PATCH", "/_test/workspaces/" + WORKSPACE, object("workspaceId", WORKSPACE, "plan", plan.name()));
    }

    void fault(JsonNode rule) throws Exception {
        control("POST", "/_test/faults", rule);
    }

    HttpResponse<String> raw(String method, String path, JsonNode body, String bearer, boolean admin, Duration timeout)
            throws Exception {
        URI uri = server.baseUri().resolve(path);
        if (!uri.getHost().equals(server.baseUri().getHost())
                || uri.getPort() != server.baseUri().getPort()) {
            throw new IllegalArgumentException("Test HTTP requests must stay inside Mini-Slack");
        }
        HttpRequest.Builder request =
                HttpRequest.newBuilder(uri).timeout(timeout).header("Content-Type", "application/json");
        if (!bearer.isEmpty()) {
            request.header("Authorization", "Bearer " + bearer);
        }
        if (admin) {
            request.header("X-Mini-Slack-Secret", server.testSecret());
        }
        request.method(
                method,
                method.equals("GET") || method.equals("DELETE")
                        ? HttpRequest.BodyPublishers.noBody()
                        : HttpRequest.BodyPublishers.ofString(body.toString()));
        return client.send(request.build(), HttpResponse.BodyHandlers.ofString());
    }

    static String encode(String value) {
        return URLEncoder.encode(value, StandardCharsets.UTF_8);
    }

    @Override
    public void close() {
        client.close();
    }
}
