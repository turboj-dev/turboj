package mini.slack;

public enum Plan {
    FREE,
    BUSINESS_PLUS,
    ENTERPRISE
}
