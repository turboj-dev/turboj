package mini.slack;

import static mini.slack.Json.*;
import static org.assertj.core.api.Assertions.*;
import static org.junit.platform.engine.discovery.DiscoverySelectors.selectClass;

import java.nio.file.Files;
import java.nio.file.Path;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import org.junit.platform.testkit.engine.EngineTestKit;

class EvidenceTest {
    @TempDir
    Path directory;

    @Test
    void failing_assertions_remain_failures_in_cherry_test_evidence() throws Exception {
        String previous = System.getProperty("mini.slack.reportDir");
        System.setProperty("mini.slack.reportDir", directory.toString());
        try {
            EngineTestKit.engine("junit-jupiter")
                    .selectors(selectClass(FailingProbe.class))
                    .execute()
                    .testEvents()
                    .assertStatistics(stats -> stats.failed(1));
            try (var files = Files.list(directory.resolve("integration"))) {
                Path report = files.findFirst().orElseThrow();
                var row = MAPPER.readTree(Files.readAllLines(report).getFirst());
                assertThat(row.path("passed").asBoolean()).isFalse();
                assertThat(row.path("reason").asString())
                        .contains(
                                "intentional assertion",
                                "Mini-Slack scenario:",
                                "HTTP evidence:",
                                "auth.test",
                                "response");
                assertThat(row.path("full_name").asString())
                        .isEqualTo("mini_slack_project_evidence_suite_failure_test");
                assertThat(row.path("authorization").isNull()).isTrue();
            }
        } finally {
            if (previous == null) {
                System.clearProperty("mini.slack.reportDir");
            } else {
                System.setProperty("mini.slack.reportDir", previous);
            }
        }
    }

    @Test
    void evidence_rejects_path_traversal() {
        Evidence evidence = new Evidence();
        assertThatThrownBy(() -> evidence.report(
                        directory,
                        "../escape",
                        "mini_slack_project_evidence_suite_failure_test",
                        true,
                        "",
                        "http://127.0.0.1"))
                .isInstanceOf(IllegalArgumentException.class);
    }

    static class FailingProbe {
        @MiniSlackTest
        void mini_slack_project_evidence_suite_failure_test(MiniSlackServer server) throws Exception {
            try (HttpFixture http = new HttpFixture(server)) {
                http.post("auth.test", object());
                throw new AssertionError("intentional assertion");
            }
        }
    }
}
