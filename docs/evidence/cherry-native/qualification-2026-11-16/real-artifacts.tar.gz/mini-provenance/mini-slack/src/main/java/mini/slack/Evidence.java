package mini.slack;

import static mini.slack.Json.*;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import tools.jackson.databind.JsonNode;
import tools.jackson.databind.node.ObjectNode;

final class Evidence {
    private static final Set<String> PRIVATE_FIELDS = Set.of(
            "authorization",
            "token",
            "access_token",
            "refresh_token",
            "password",
            "secret",
            "email",
            "emails",
            "real_name",
            "display_name",
            "displayname",
            "first_name",
            "last_name",
            "givenname",
            "familyname",
            "custom_message");
    private final List<ObjectNode> requests = new ArrayList<>();
    private long sequence;
    private boolean overflow;

    synchronized void add(ObjectNode request) {
        request.put("sequence", ++sequence);
        requests.add(request);
        if (requests.size() > 10000) {
            requests.removeFirst();
            overflow = true;
        }
    }

    synchronized List<ObjectNode> requests() {
        return requests.stream().map(ObjectNode::deepCopy).toList();
    }

    synchronized void clear() {
        requests.clear();
        overflow = false;
    }

    synchronized void report(
            Path reportDirectory, String packageName, String fullName, boolean passed, String reason, String baseUrl)
            throws IOException {
        if (!packageName.matches("[A-Za-z0-9_-]+")
                || !fullName.matches("[a-z0-9_]+_project_[a-z0-9_]+_suite_[a-z0-9_]+_test")) {
            throw new IllegalArgumentException("Invalid Cherry Test evidence identity");
        }
        String[] projectAndRest = fullName.split("_project_", 2);
        String[] suiteAndTest = projectAndRest[1].split("_suite_", 2);
        String test = suiteAndTest[1].substring(0, suiteAndTest[1].length() - 5);
        StringBuilder lines = new StringBuilder();
        for (ObjectNode request : requests) {
            ObjectNode line = object(
                    "project",
                    projectAndRest[0],
                    "suite",
                    suiteAndTest[0],
                    "test",
                    test,
                    "full_name",
                    fullName,
                    "scope",
                    "mini_slack",
                    "target_project",
                    projectAndRest[0],
                    "target_service",
                    "mini-slack",
                    "elapsed_ms",
                    request.path("durationMs"),
                    "method",
                    request.path("method"),
                    "url",
                    baseUrl + request.path("path").asString(),
                    "status",
                    request.path("status"),
                    "request_body",
                    object(
                                    "query",
                                    request.path("query"),
                                    "body",
                                    request.path("body"),
                                    "faultId",
                                    request.path("faultId"),
                                    "correlationId",
                                    request.path("correlationId"))
                            .toString(),
                    "authorization",
                    null,
                    "response_body",
                    request.path("response").toString(),
                    "passed",
                    passed && !overflow,
                    "reason",
                    overflow ? "Mini-Slack evidence limit exceeded" : reason.isEmpty() ? null : scrubText(reason));
            lines.append(line).append('\n');
        }
        Path directory = reportDirectory.resolve("integration");
        Files.createDirectories(directory);
        Files.writeString(
                directory.resolve(packageName + "-" + fullName + ".jsonl"),
                lines,
                StandardOpenOption.CREATE,
                StandardOpenOption.APPEND);
        if (overflow) {
            throw new IllegalStateException("Mini-Slack evidence limit exceeded");
        }
    }

    static JsonNode sanitize(JsonNode value) {
        if (value.isObject()) {
            ObjectNode out = object();
            value.properties().forEach(entry -> {
                String key = entry.getKey().toLowerCase(Locale.ROOT);
                out.set(
                        entry.getKey(),
                        PRIVATE_FIELDS.contains(key) || key.contains("secret") || key.contains("token")
                                ? MAPPER.valueToTree("[REDACTED]")
                                : sanitize(entry.getValue()));
            });
            return out;
        }
        if (value.isArray()) {
            List<JsonNode> out = new ArrayList<>();
            value.forEach(item -> out.add(sanitize(item)));
            return array(out);
        }
        return value.isString() ? MAPPER.valueToTree(scrubText(value.asString())) : value.deepCopy();
    }

    static String scrubText(String value) {
        return value.replaceAll("(?i)xox[baprs]-[^\\s\"'&,}]+", "[REDACTED]")
                .replaceAll("[A-Za-z0-9.!#$%&'*+/=?^_`{|}~-]+@[A-Za-z0-9.-]+", "[REDACTED]");
    }
}
