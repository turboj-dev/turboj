package mini.slack;

import static mini.slack.Json.*;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Locale;
import tools.jackson.databind.JsonNode;

public final class Fixtures {
    private Fixtures() {}

    public static JsonNode load(String name) throws IOException {
        if (!List.of("empty", "small", "large").contains(name)) {
            throw new IllegalArgumentException("Unknown Mini-Slack fixture");
        }
        try (InputStream stream = Fixtures.class.getResourceAsStream("/fixtures/" + name + ".json")) {
            if (stream == null) {
                throw new IOException("Mini-Slack fixture missing: " + name);
            }
            return MAPPER.readTree(stream);
        }
    }

    static void seed(SlackState state, JsonNode fixture) {
        SlackState candidate = new SlackState(state.clock);
        if (fixture.has("community")) {
            community(candidate, fixture);
        } else {
            if (!fixture.path("workspaces").isArray()) {
                throw new ApiException("invalid_fixture");
            }
            for (JsonNode input : fixture.path("workspaces")) {
                SlackState.Workspace workspace = candidate.createWorkspace(input);
                for (JsonNode user : input.path("users")) {
                    candidate.createUser(workspace, user);
                }
                for (JsonNode channel : input.path("channels")) {
                    candidate.createChannel(workspace, channel);
                }
                for (JsonNode invite : input.path("invitations")) {
                    candidate.invite(workspace, invite);
                }
            }
        }
        for (JsonNode token : fixture.path("tokens")) {
            candidate.createToken(token);
        }
        state.replace(candidate);
    }

    private static void community(SlackState state, JsonNode fixture) {
        String size = required(fixture, "community");
        if (!List.of("empty", "small", "large").contains(size)) {
            throw new ApiException("invalid_fixture");
        }
        SlackState.Workspace workspace = state.createWorkspace(object(
                "id",
                text(fixture, "workspaceId", "TTEST0001"),
                "name",
                text(fixture, "name", "JUG Lugano Local"),
                "plan",
                text(fixture, "plan", "FREE")));
        state.createUser(
                workspace,
                object("id", "UADMIN0001", "name", "admin", "email", "admin@example.test", "is_admin", true));
        state.createUser(workspace, object("id", "UBOT000001", "name", "platform-bot", "is_bot", true));
        if (!size.equals("empty")) {
            state.createUser(
                    workspace,
                    object(
                            "id",
                            "UOWNER0001",
                            "name",
                            "owner",
                            "email",
                            "owner@example.test",
                            "is_primary_owner",
                            true));
        }
        List<String> names = List.of(
                "annunci",
                "presentazioni",
                "java-jvm",
                "java-ee",
                "spring",
                "java-ai",
                "eventi-talk",
                "studenti-mentoring",
                "staff");
        for (int i = 0; i < names.size(); i++) {
            boolean privateChannel = names.get(i).equals("staff");
            state.createChannel(
                    workspace,
                    object(
                            "id",
                            String.format(Locale.ROOT, "CLOCAL%04d", i + 1),
                            "name",
                            names.get(i),
                            "creator",
                            "UADMIN0001",
                            "is_private",
                            privateChannel,
                            "members",
                            privateChannel ? List.of("UADMIN0001") : List.of("UADMIN0001", "UBOT000001")));
        }
        if (size.equals("small")) {
            for (int i = 1; i <= 6; i++) {
                String name = i <= 3 ? "student" + i : "professional" + (i - 3);
                state.createUser(
                        workspace,
                        object(
                                "id",
                                String.format(Locale.ROOT, "UMEMBER%03d", i),
                                "name",
                                name,
                                "real_name",
                                "Synthetic Member " + i,
                                "email",
                                name + "@example.test"));
            }
            state.createUser(
                    workspace,
                    object(
                            "id",
                            "UINACTIVE1",
                            "name",
                            "inactive",
                            "email",
                            "inactive@example.test",
                            "state",
                            "DEACTIVATED"));
            state.invite(workspace, object("email", "pending@example.test", "channel_ids", "CLOCAL0001"));
        }
        if (size.equals("large")) {
            int count = integer(fixture, "members", 1000, 1000, 10000);
            for (int i = 1; i <= count; i++) {
                state.createUser(
                        workspace,
                        object(
                                "id",
                                String.format(Locale.ROOT, "ULARGE%06d", i),
                                "name",
                                "member" + i,
                                "email",
                                "member" + i + "@example.test",
                                "real_name",
                                "Synthetic Member " + i));
            }
        }
    }
}
