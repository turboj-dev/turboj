package mini.slack;

import static mini.slack.Json.*;

import java.util.ArrayList;
import java.util.List;
import org.jspecify.annotations.Nullable;
import tools.jackson.databind.JsonNode;
import tools.jackson.databind.node.ObjectNode;

final class Faults {
    record Applied(
            String id,
            int httpStatus,
            String error,
            int retryAfterSeconds,
            int delayMs,
            boolean malformed,
            boolean incompletePage,
            JsonNode responseBody) {}

    private static final class Rule {
        final String method;
        final String workspaceId;
        final Applied fault;
        int remaining;

        Rule(String method, String workspaceId, Applied fault, int remaining) {
            this.method = method;
            this.workspaceId = workspaceId;
            this.fault = fault;
            this.remaining = remaining;
        }
    }

    private final List<Rule> rules = new ArrayList<>();
    private int sequence;

    ObjectNode add(JsonNode input) {
        int count = integer(input, "failNext", 1, 1, 100000);
        int status = integer(input, "httpStatus", 200, 200, 599);
        if (status >= 300 && status < 400) {
            throw new ApiException("redirect_fault_not_supported");
        }
        Applied fault = new Applied(
                "F" + ++sequence,
                status,
                text(input, "error", status == 429 ? "ratelimited" : status >= 500 ? "service_unavailable" : ""),
                integer(input, "retryAfterSeconds", 1, 0, 3600),
                integer(input, "delayMs", 0, 0, 30000),
                bool(input, "malformed", false),
                bool(input, "incompletePage", false),
                input.path("responseBody"));
        rules.add(new Rule(required(input, "method"), text(input, "workspaceId", ""), fault, count));
        return object("id", fault.id(), "remaining", count);
    }

    @Nullable
    Applied take(String method, String workspaceId) {
        for (Rule rule : rules) {
            if (rule.remaining > 0
                    && (rule.method.equals(method) || rule.method.equals("*"))
                    && (rule.workspaceId.isEmpty() || rule.workspaceId.equals(workspaceId))) {
                rule.remaining--;
                return rule.fault;
            }
        }
        return null;
    }

    void clear() {
        rules.clear();
    }
}
