package mini.slack;

import static mini.slack.Json.*;
import static org.assertj.core.api.Assertions.*;

import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.io.TempDir;
import tools.jackson.databind.JsonNode;

class JugWorkflowIT {
    private MiniSlackServer server;

    @TempDir
    Path temporary;

    @BeforeEach
    void useServer(MiniSlackServer runningServer) {
        server = runningServer;
    }

    @MiniSlackTest
    void mini_slack_project_jug_suite_assisted_invitation_test() throws Exception {
        try (HttpFixture http = new HttpFixture(server);
                JugReconciler jug = new JugReconciler(
                        server.baseUri(), http.token, Plan.FREE, Thread::sleep, temporary.resolve("members.json"))) {
            var member = new JugReconciler.Member(
                    "registration-1", "student@example.test", JugReconciler.Category.STUDENT, true);
            assertThat(member.protectedAccess()).isTrue();
            assertThat(jug.lookup(member.email).path("error").asString()).isEqualTo("users_not_found");
            assertThat(jug.reconcile(List.of(member))).isTrue();
            assertThat(member.task).isEqualTo(JugReconciler.Task.ASSISTED_INVITATION);
            assertThat(member.verified).isEqualTo(JugReconciler.Verified.ABSENT);
            JsonNode invite = http.control(
                    "POST",
                    "/_test/invitations",
                    object("workspaceId", HttpFixture.WORKSPACE, "email", member.email, "channel_ids", "CLOCAL0001"));
            assertThat(jug.reconcile(List.of(member))).isTrue();
            assertThat(member.verified).isEqualTo(JugReconciler.Verified.ABSENT);
            http.control(
                    "POST",
                    "/_test/invitations/" + invite.path("id").asString() + "/accept",
                    object("workspaceId", HttpFixture.WORKSPACE));
            assertThat(jug.reconcile(List.of(member))).isTrue();
            assertThat(member.verified).isEqualTo(JugReconciler.Verified.ACTIVE);
            assertThat(member.task).isEqualTo(JugReconciler.Task.NONE);
        }
    }

    @MiniSlackTest
    void mini_slack_project_jug_suite_expired_professional_test() throws Exception {
        try (HttpFixture http = new HttpFixture(server);
                JugReconciler jug = new JugReconciler(
                        server.baseUri(), http.token, Plan.FREE, Thread::sleep, temporary.resolve("members.json"))) {
            var member = new JugReconciler.Member(
                    "registration-2", "professional@example.test", JugReconciler.Category.PROFESSIONAL, false);
            String id = http.addUser(member.email).path("id").asString();
            assertThat(member.protectedAccess()).isFalse();
            assertThat(jug.reconcile(List.of(member))).isTrue();
            assertThat(member.verified).isEqualTo(JugReconciler.Verified.ACTIVE);
            assertThat(member.task).isEqualTo(JugReconciler.Task.MANUAL_DEACTIVATION);
            http.control("POST", "/_test/users/" + id + "/deactivate", object("workspaceId", HttpFixture.WORKSPACE));
            assertThat(jug.reconcile(List.of(member))).isTrue();
            assertThat(member.verified).isEqualTo(JugReconciler.Verified.DISABLED);
            assertThat(member.task).isEqualTo(JugReconciler.Task.NONE);
        }
    }

    @MiniSlackTest(plan = Plan.ENTERPRISE)
    void mini_slack_project_jug_suite_enterprise_provisioning_test() throws Exception {
        try (HttpFixture http = new HttpFixture(server);
                JugReconciler jug = new JugReconciler(
                        server.baseUri(),
                        http.token,
                        Plan.ENTERPRISE,
                        Thread::sleep,
                        temporary.resolve("members.json"))) {
            var member = new JugReconciler.Member(
                    "registration-3", "enterprise@example.test", JugReconciler.Category.STUDENT, true);
            assertThat(jug.reconcile(List.of(member))).isTrue();
            assertThat(member.task).isEqualTo(JugReconciler.Task.AWAITING_ACCEPTANCE);
            assertThat(member.verified).isEqualTo(JugReconciler.Verified.ABSENT);
            JsonNode invite =
                    http.state().path("workspaces").get(0).path("invitations").get(0);
            http.control(
                    "POST",
                    "/_test/invitations/" + invite.path("id").asString() + "/accept",
                    object("workspaceId", HttpFixture.WORKSPACE));
            assertThat(jug.reconcile(List.of(member))).isTrue();
            assertThat(member.verified).isEqualTo(JugReconciler.Verified.ACTIVE);
            member.eligible = false;
            assertThat(jug.reconcile(List.of(member))).isTrue();
            assertThat(member.verified).isEqualTo(JugReconciler.Verified.ACTIVE);
            assertThat(member.task).isEqualTo(JugReconciler.Task.AWAITING_REMOVAL);
            assertThat(jug.reconcile(List.of(member))).isTrue();
            assertThat(member.verified).isEqualTo(JugReconciler.Verified.DISABLED);
            JsonNode account = http.api("GET", "/scim/v2/Users/" + member.slackId, object());
            assertThat(account.path("active").asBoolean()).isTrue();
        }
    }

    @MiniSlackTest
    void mini_slack_project_jug_suite_unavailable_preserves_verified_state_test() throws Exception {
        Path repository = temporary.resolve("members.json");
        List<Duration> waits = new ArrayList<>();
        try (HttpFixture http = new HttpFixture(server);
                JugReconciler jug =
                        new JugReconciler(server.baseUri(), http.token, Plan.FREE, waits::add, repository)) {
            var member = new JugReconciler.Member(
                    "registration-4", "outage@example.test", JugReconciler.Category.PROFESSIONAL, true);
            String id = http.addUser(member.email).path("id").asString();
            assertThat(jug.reconcile(List.of(member))).isTrue();
            byte[] previous = Files.readAllBytes(repository);
            http.control("POST", "/_test/users/" + id + "/deactivate", object("workspaceId", HttpFixture.WORKSPACE));
            http.fault(object("method", "users.list", "failNext", 3, "httpStatus", 503));
            assertThat(jug.reconcile(List.of(member))).isFalse();
            assertThat(member.verified).isEqualTo(JugReconciler.Verified.ACTIVE);
            assertThat(Files.readAllBytes(repository)).isEqualTo(previous);
            assertThat(waits).containsExactly(Duration.ofSeconds(1), Duration.ofSeconds(2));
            assertThat(jug.reconcile(List.of(member))).isTrue();
            assertThat(member.verified).isEqualTo(JugReconciler.Verified.ABSENT);
        }
    }

    @MiniSlackTest(fixture = "large")
    void mini_slack_project_jug_suite_bulk_reconciliation_test() throws Exception {
        List<Duration> waits = new ArrayList<>();
        try (HttpFixture http = new HttpFixture(server);
                JugReconciler jug = new JugReconciler(
                        server.baseUri(), http.token, Plan.FREE, waits::add, temporary.resolve("members.json"))) {
            List<JugReconciler.Member> members = new ArrayList<>();
            for (int i = 1; i <= 100; i++) {
                members.add(new JugReconciler.Member(
                        "new-" + i, "new" + i + "@example.test", JugReconciler.Category.STUDENT, true));
            }
            for (int i = 1; i <= 35; i++) {
                members.add(new JugReconciler.Member(
                        "existing-" + i, "member" + i + "@example.test", JugReconciler.Category.PROFESSIONAL, i <= 20));
            }
            for (int i = 36; i <= 40; i++) {
                String id = String.format(java.util.Locale.ROOT, "ULARGE%06d", i);
                http.control(
                        "PATCH", "/_test/users/" + id, object("workspaceId", HttpFixture.WORKSPACE, "email", null));
                var missing = new JugReconciler.Member(
                        "missing-" + i, "member" + i + "@example.test", JugReconciler.Category.STUDENT, true);
                missing.slackId = id;
                members.add(missing);
            }
            members.add(new JugReconciler.Member(
                    "conflict-1", "member50@example.test", JugReconciler.Category.STUDENT, true));
            members.add(new JugReconciler.Member(
                    "conflict-2", "member50@example.test", JugReconciler.Category.STUDENT, true));
            http.fault(object("method", "users.list", "failNext", 2, "httpStatus", 429, "retryAfterSeconds", 1));
            assertThat(jug.reconcile(members)).isTrue();
            assertThat(waits).containsExactly(Duration.ofSeconds(1), Duration.ofSeconds(1));
            assertThat(members.stream().filter(m -> m.task == JugReconciler.Task.ASSISTED_INVITATION))
                    .hasSize(100);
            assertThat(members.stream().filter(m -> m.task == JugReconciler.Task.MANUAL_DEACTIVATION))
                    .hasSize(15);
            assertThat(members.stream().filter(m -> m.task == JugReconciler.Task.CONFLICT))
                    .hasSize(7);
            for (JugReconciler.Member member : members) {
                if (member.task == JugReconciler.Task.ASSISTED_INVITATION) {
                    JsonNode invite = http.control(
                            "POST",
                            "/_test/invitations",
                            object(
                                    "workspaceId",
                                    HttpFixture.WORKSPACE,
                                    "email",
                                    member.email,
                                    "channel_ids",
                                    "CLOCAL0001"));
                    http.control(
                            "POST",
                            "/_test/invitations/" + invite.path("id").asString() + "/accept",
                            object("workspaceId", HttpFixture.WORKSPACE));
                } else if (member.task == JugReconciler.Task.MANUAL_DEACTIVATION) {
                    http.control(
                            "POST",
                            "/_test/users/" + member.slackId + "/deactivate",
                            object("workspaceId", HttpFixture.WORKSPACE));
                }
            }
            assertThat(jug.reconcile(members)).isTrue();
            assertThat(members.stream().filter(m -> m.verified == JugReconciler.Verified.ACTIVE))
                    .hasSize(120);
            assertThat(members.stream().filter(m -> m.verified == JugReconciler.Verified.DISABLED))
                    .hasSize(15);
            List<String> ids = members.stream()
                    .filter(m -> m.verified == JugReconciler.Verified.ACTIVE)
                    .map(m -> m.slackId)
                    .toList();
            for (int start = 0; start < ids.size(); start += 50) {
                assertThat(http.post(
                                        "conversations.invite",
                                        object(
                                                "channel",
                                                "CLOCAL0003",
                                                "users",
                                                String.join(",", ids.subList(start, Math.min(start + 50, ids.size())))))
                                .path("ok")
                                .asBoolean())
                        .isTrue();
            }
            assertThat(http.get("conversations.members?channel=CLOCAL0003&limit=1000")
                            .path("members"))
                    .hasSize(122);
        }
    }
}
