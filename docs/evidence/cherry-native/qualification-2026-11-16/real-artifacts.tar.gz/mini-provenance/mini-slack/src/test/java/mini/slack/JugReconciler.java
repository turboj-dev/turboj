package mini.slack;

import static mini.slack.Json.*;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.time.Duration;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import tools.jackson.databind.JsonNode;
import tools.jackson.databind.node.ObjectNode;

final class JugReconciler implements AutoCloseable {
    enum Category {
        STUDENT,
        PROFESSIONAL
    }

    enum Verified {
        UNKNOWN,
        ABSENT,
        ACTIVE,
        DISABLED
    }

    enum Task {
        NONE,
        ASSISTED_INVITATION,
        AWAITING_ACCEPTANCE,
        MANUAL_DEACTIVATION,
        AWAITING_REMOVAL,
        CONFLICT
    }

    static final class Member {
        final String id;
        final String email;
        final Category category;
        boolean eligible;
        Verified verified = Verified.UNKNOWN;
        Task task = Task.NONE;
        String slackId = "";

        Member(String id, String email, Category category, boolean eligible) {
            this.id = id;
            this.email = email;
            this.category = category;
            this.eligible = eligible;
        }

        boolean protectedAccess() {
            return eligible;
        }
    }

    interface Backoff {
        void waitFor(Duration delay) throws InterruptedException;
    }

    private final URI base;
    private final String token;
    private final Plan plan;
    private final Backoff backoff;
    private final Path repository;
    private final HttpClient client =
            HttpClient.newBuilder().followRedirects(HttpClient.Redirect.NEVER).build();
    private final Set<String> issuedInvitations = new HashSet<>();

    JugReconciler(URI base, String token, Plan plan, Backoff backoff, Path repository) {
        SlackEndpoints.forEnvironment("test", URI.create(base + "/api"), URI.create(base + "/scim/v2"));
        this.base = base;
        this.token = token;
        this.plan = plan;
        this.backoff = backoff;
        this.repository = repository;
    }

    boolean reconcile(List<Member> members) throws IOException, InterruptedException {
        List<JsonNode> snapshot;
        try {
            snapshot = listAll();
        } catch (Unavailable exception) {
            return false;
        }
        Map<String, JsonNode> byEmail = new HashMap<>();
        Map<String, JsonNode> byId = new HashMap<>();
        Set<String> ambiguous = new HashSet<>();
        Set<String> domainEmails = new HashSet<>();
        for (Member member : members) {
            if (!domainEmails.add(member.email)) {
                ambiguous.add(member.email);
            }
        }
        for (JsonNode user : snapshot) {
            byId.put(user.path("id").asString(), user);
            String email = user.path("profile").path("email").asString("");
            if (!email.isEmpty() && byEmail.putIfAbsent(email, user) != null) {
                ambiguous.add(email);
            }
        }
        for (Member member : members) {
            JsonNode user = byEmail.get(member.email);
            if (member.email.isEmpty()
                    || ambiguous.contains(member.email)
                    || (user != null
                            && !member.slackId.isEmpty()
                            && !member.slackId.equals(user.path("id").asString()))
                    || (user == null && !member.slackId.isEmpty() && byId.containsKey(member.slackId))) {
                member.task = Task.CONFLICT;
                continue;
            }
            if (user != null && user.path("is_invited_user").asBoolean(false)) {
                member.verified = Verified.ABSENT;
                member.task = Task.AWAITING_ACCEPTANCE;
                continue;
            }
            boolean active = user != null && !user.path("deleted").asBoolean();
            member.verified = active ? Verified.ACTIVE : member.eligible ? Verified.ABSENT : Verified.DISABLED;
            if (user != null) {
                member.slackId = user.path("id").asString();
            }
            member.task = Task.NONE;
            if (member.eligible && !active) {
                if (plan == Plan.ENTERPRISE) {
                    if (!issuedInvitations.contains(member.email)) {
                        try {
                            call(
                                    "POST",
                                    "/api/admin.users.invite",
                                    object(
                                            "team_id",
                                            HttpFixture.WORKSPACE,
                                            "email",
                                            member.email,
                                            "channel_ids",
                                            "CLOCAL0001"));
                            issuedInvitations.add(member.email);
                        } catch (Unavailable exception) {
                            continue;
                        }
                    }
                    member.task = Task.AWAITING_ACCEPTANCE;
                } else {
                    member.task = Task.ASSISTED_INVITATION;
                }
            } else if (!member.eligible && active) {
                if (plan == Plan.ENTERPRISE) {
                    try {
                        call(
                                "POST",
                                "/api/admin.users.remove",
                                object("team_id", HttpFixture.WORKSPACE, "user_id", member.slackId));
                        member.task = Task.AWAITING_REMOVAL;
                    } catch (Unavailable exception) {
                        member.task = Task.MANUAL_DEACTIVATION;
                    }
                } else {
                    member.task = Task.MANUAL_DEACTIVATION;
                }
            }
        }
        persist(members);
        return true;
    }

    private List<JsonNode> listAll() throws IOException, InterruptedException {
        List<JsonNode> users = new ArrayList<>();
        Set<String> cursors = new HashSet<>();
        Set<String> ids = new HashSet<>();
        String cursor = "";
        do {
            JsonNode page = call("GET", "/api/users.list?limit=100&cursor=" + HttpFixture.encode(cursor), object());
            if (!page.path("members").isArray()
                    || !page.path("response_metadata").has("next_cursor")) {
                throw new Unavailable();
            }
            for (JsonNode user : page.path("members")) {
                if (!ids.add(user.path("id").asString())) {
                    throw new Unavailable();
                }
                users.add(user);
            }
            cursor = page.path("response_metadata").path("next_cursor").asString();
            if (!cursor.isEmpty() && !cursors.add(cursor)) {
                throw new Unavailable();
            }
        } while (!cursor.isEmpty());
        return users;
    }

    JsonNode lookup(String email) throws IOException, InterruptedException {
        return call("GET", "/api/users.lookupByEmail?email=" + HttpFixture.encode(email), object());
    }

    private JsonNode call(String method, String path, JsonNode input) throws IOException, InterruptedException {
        for (int attempt = 0; attempt < 3; attempt++) {
            HttpRequest.Builder builder = HttpRequest.newBuilder(base.resolve(path))
                    .timeout(Duration.ofSeconds(2))
                    .header("Authorization", "Bearer " + token)
                    .header("Content-Type", "application/json");
            builder.method(
                    method,
                    method.equals("GET")
                            ? HttpRequest.BodyPublishers.noBody()
                            : HttpRequest.BodyPublishers.ofString(input.toString()));
            HttpResponse<String> response;
            try {
                response = client.send(builder.build(), HttpResponse.BodyHandlers.ofString());
            } catch (IOException exception) {
                if (attempt == 2) {
                    throw new Unavailable();
                }
                backoff.waitFor(Duration.ofSeconds(1L << attempt));
                continue;
            }
            if (response.statusCode() == 429 || response.statusCode() >= 500) {
                if (attempt == 2) {
                    throw new Unavailable();
                }
                int seconds = response.statusCode() == 429
                        ? Integer.parseInt(
                                response.headers().firstValue("Retry-After").orElse("1"))
                        : 1 << attempt;
                backoff.waitFor(Duration.ofSeconds(seconds));
                continue;
            }
            if (response.statusCode() != 200) {
                throw new Unavailable();
            }
            JsonNode json;
            try {
                json = MAPPER.readTree(response.body());
            } catch (tools.jackson.core.JacksonException exception) {
                throw new Unavailable();
            }
            if (!json.path("ok").asBoolean() && !json.path("error").asString("").equals("users_not_found")) {
                throw new Unavailable();
            }
            return json;
        }
        throw new Unavailable();
    }

    private void persist(List<Member> members) throws IOException {
        List<ObjectNode> rows = members.stream()
                .map(m -> object(
                        "id",
                        m.id,
                        "category",
                        m.category.name(),
                        "eligible",
                        m.eligible,
                        "verified",
                        m.verified.name(),
                        "slackId",
                        m.slackId,
                        "task",
                        m.task.name()))
                .toList();
        Path pending = repository.resolveSibling(repository.getFileName() + ".pending");
        Files.writeString(pending, array(rows).toString());
        Files.move(pending, repository, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
    }

    private static final class Unavailable extends RuntimeException {}

    @Override
    public void close() {
        client.close();
    }
}
