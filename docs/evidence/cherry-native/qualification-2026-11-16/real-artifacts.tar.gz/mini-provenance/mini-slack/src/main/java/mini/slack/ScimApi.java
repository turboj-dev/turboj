package mini.slack;

import static mini.slack.Json.*;

import java.time.Instant;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import mini.slack.SlackState.Context;
import mini.slack.SlackState.User;
import tools.jackson.databind.JsonNode;
import tools.jackson.databind.node.ObjectNode;

final class ScimApi {
    static final String USER_SCHEMA = "urn:ietf:params:scim:schemas:core:2.0:User";
    static final String PATCH_SCHEMA = "urn:ietf:params:scim:api:messages:2.0:PatchOp";
    private final SlackState state;

    ScimApi(SlackState state) {
        this.state = state;
    }

    record Result(int status, JsonNode body) {}

    Result call(String verb, String path, String bearer, JsonNode input, String baseUrl) {
        Context c = state.authenticate(bearer, input);
        if (c.workspace().plan == Plan.FREE) {
            throw new ApiException(403, "plus_teams_only");
        }
        c.admin();
        c.scope("admin");
        if (c.workspace().plan == Plan.ENTERPRISE && !c.token().orgLevel()) {
            throw new ApiException(403, "non_org_teams_only");
        }
        if (path.equals("/scim/v2/Users")) {
            if (verb.equals("GET")) {
                if (input.has("filter")) {
                    throw new ApiException(400, "invalid_query");
                }
                int start = integer(input, "startIndex", 1, 1, Integer.MAX_VALUE);
                int count = integer(input, "count", 100, 0, 1000);
                List<User> users = c.workspace().users.values().stream()
                        .filter(u -> !u.flag("is_bot"))
                        .sorted(Comparator.comparing(u -> u.id))
                        .toList();
                int from = Math.min(start - 1, users.size());
                List<ObjectNode> page = users.subList(from, Math.min(from + count, users.size())).stream()
                        .map(u -> resource(u, baseUrl))
                        .toList();
                return new Result(
                        200,
                        object(
                                "schemas",
                                List.of("urn:ietf:params:scim:api:messages:2.0:ListResponse"),
                                "totalResults",
                                users.size(),
                                "startIndex",
                                start,
                                "itemsPerPage",
                                page.size(),
                                "Resources",
                                page));
            }
            if (!verb.equals("POST")) {
                throw new ApiException(405, "bad_method");
            }
            if (!strings(input.path("schemas")).contains(USER_SCHEMA)) {
                throw new ApiException("invalid_schema");
            }
            rejectUnsupported(
                    input, Set.of("schemas", "userName", "name", "displayName", "emails", "active", "externalId"));
            ObjectNode attrs = attributes(input);
            attrs.put("name", required(input, "userName"));
            if (!attrs.has("email")) {
                throw new ApiException("missing_primary_email");
            }
            attrs.put("state", bool(input, "active", true) ? "ACTIVE" : "DEACTIVATED");
            validateUsername(c, "", attrs);
            User created = state.createUser(c.workspace(), attrs);
            return new Result(201, resource(created, baseUrl));
        }
        if (!path.matches("/scim/v2/Users/[UW][A-Z0-9]{3,40}")) {
            throw new ApiException(404, "bad_endpoint");
        }
        User user = state.user(c.workspace(), path.substring("/scim/v2/Users/".length()));
        if (user.flag("is_bot")) {
            throw new ApiException(404, "user_not_found");
        }
        if (verb.equals("GET")) {
            return new Result(200, resource(user, baseUrl));
        }
        if (user.flag("is_primary_owner") || user.rank() > c.principal().rank()) {
            throw new ApiException(403, "cannot_modify_owner");
        }
        if (verb.equals("DELETE")) {
            state.accountActive(c.workspace(), user, false);
            return new Result(204, object());
        }
        if (!verb.equals("PATCH")) {
            throw new ApiException(405, "bad_method");
        }
        if (!strings(input.path("schemas")).contains(PATCH_SCHEMA)
                || !input.path("Operations").isArray()
                || input.path("Operations").isEmpty()) {
            throw new ApiException("invalid_schema");
        }
        ObjectNode updates = object();
        Boolean active = null;
        for (JsonNode op : input.path("Operations")) {
            String operation = required(op, "op").toLowerCase(Locale.ROOT);
            if (!Set.of("replace", "add").contains(operation) || !op.has("value")) {
                throw new ApiException("invalid_operation");
            }
            String attribute = text(op, "path", "");
            JsonNode value = op.path("value");
            ObjectNode document;
            if (attribute.isEmpty() && value.isObject()) {
                document = (ObjectNode) value;
            } else if (attribute.equals("name.givenName")) {
                document = object("name", object("givenName", value));
            } else if (attribute.equals("name.familyName")) {
                document = object("name", object("familyName", value));
            } else {
                document = object(attribute, value);
            }
            rejectUnsupported(document, Set.of("userName", "name", "displayName", "emails", "active", "externalId"));
            if (document.has("active")) {
                active = bool(document, "active", true);
            }
            attributes(document).properties().forEach(entry -> updates.set(entry.getKey(), entry.getValue()));
        }
        validateUsername(c, user.id, updates);
        state.updateUser(c.workspace(), user, updates);
        if (active != null) {
            state.accountActive(c.workspace(), user, active);
        }
        return new Result(200, resource(user, baseUrl));
    }

    private static ObjectNode attributes(JsonNode input) {
        ObjectNode attributes = object();
        for (String key : List.of("userName", "displayName", "externalId")) {
            if (input.has(key)) {
                attributes.put(
                        switch (key) {
                            case "userName" -> "name";
                            case "displayName" -> "display_name";
                            default -> key;
                        },
                        required(input, key));
            }
        }
        if (input.has("name")) {
            if (!input.path("name").isObject()) {
                throw new ApiException("invalid_name");
            }
            rejectUnsupported(input.path("name"), Set.of("givenName", "familyName"));
            if (input.path("name").has("givenName")) {
                attributes.put("first_name", text(input.path("name"), "givenName", ""));
            }
            if (input.path("name").has("familyName")) {
                attributes.put("last_name", text(input.path("name"), "familyName", ""));
            }
        }
        if (input.has("emails")) {
            JsonNode emails = input.path("emails");
            if (!emails.isArray() || emails.size() != 1) {
                throw new ApiException("missing_primary_email");
            }
            attributes.put("email", email(required(emails.get(0), "value")));
        }
        return attributes;
    }

    private static void validateUsername(Context context, String userId, JsonNode attributes) {
        if (!attributes.has("name")) {
            return;
        }
        String name = required(attributes, "name");
        if (name.length() > 21) {
            throw new ApiException("username_too_long");
        }
        if (context.workspace().users.values().stream()
                        .anyMatch(user ->
                                !user.id.equals(userId) && user.value("name").equalsIgnoreCase(name))
                || context.workspace().channels.values().stream()
                        .anyMatch(channel -> channel.name.equalsIgnoreCase(name))) {
            throw new ApiException(409, "username_taken");
        }
    }

    private static void rejectUnsupported(JsonNode input, Set<String> allowed) {
        for (String key : input.propertyNames()) {
            if (!allowed.contains(key)) {
                throw new ApiException("invalid_attribute");
            }
        }
    }

    private static ObjectNode resource(User user, String baseUrl) {
        ObjectNode result = object(
                "schemas",
                List.of(USER_SCHEMA),
                "id",
                user.id,
                "userName",
                user.value("name"),
                "displayName",
                user.value("display_name"),
                "active",
                user.accountActive,
                "name",
                object("givenName", user.value("first_name"), "familyName", user.value("last_name")),
                "emails",
                user.value("email").isEmpty()
                        ? List.of()
                        : List.of(object("value", user.value("email"), "primary", true, "type", "work")),
                "meta",
                object(
                        "resourceType",
                        "User",
                        "created",
                        Instant.ofEpochSecond(user.created).toString(),
                        "lastModified",
                        Instant.ofEpochSecond(user.updated).toString(),
                        "location",
                        baseUrl + "/scim/v2/Users/" + user.id));
        if (!user.value("externalId").isEmpty()) {
            result.put("externalId", user.value("externalId"));
        }
        return result;
    }

    static ObjectNode error(int status, String message) {
        return object(
                "schemas",
                List.of("urn:ietf:params:scim:api:messages:2.0:Error"),
                "status",
                status,
                "detail",
                switch (message) {
                    case "not_authed" -> "missing_authentication";
                    case "invalid_auth",
                            "token_revoked",
                            "token_expired",
                            "account_inactive",
                            "missing_scope",
                            "not_an_admin",
                            "not_allowed_token_type" -> "invalid_authentication";
                    case "team_access_not_granted" -> "permission_denied";
                    case "user_not_found" -> "no_such_user";
                    case "invalid_schema" -> "missing_schema_element";
                    case "invalid_email" -> "bad_email_address";
                    case "invalid_name", "invalid_arguments", "invalid_operation", "invalid_attribute" ->
                        "invalid_request_payload";
                    case "bad_method" -> "method_not_allowed";
                    default -> message;
                });
    }
}
