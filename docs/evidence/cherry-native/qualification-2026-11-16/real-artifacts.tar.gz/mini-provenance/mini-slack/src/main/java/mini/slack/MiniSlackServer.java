package mini.slack;

import static mini.slack.Json.*;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;
import java.io.IOException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.URI;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.time.Clock;
import java.time.Instant;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import org.jspecify.annotations.Nullable;
import tools.jackson.core.JacksonException;
import tools.jackson.databind.JsonNode;
import tools.jackson.databind.node.ObjectNode;

public final class MiniSlackServer implements AutoCloseable {
    public record Settings(
            String address, int port, String environment, boolean containerMode, boolean testApi, String testSecret) {
        public Settings {
            if (!List.of("test", "development").contains(environment)) {
                throw new IllegalArgumentException("Mini-Slack is a test simulator; production startup is forbidden");
            }
            if (port < 0 || port > 65535) {
                throw new IllegalArgumentException("Invalid Mini-Slack port");
            }
            if (testApi && (testSecret == null || testSecret.length() < 32)) {
                throw new IllegalArgumentException("Test API requires a dedicated secret of at least 32 characters");
            }
            if (!List.of("127.0.0.1", "::1", "0.0.0.0").contains(address)
                    || (address.equals("0.0.0.0") && !containerMode)) {
                throw new IllegalArgumentException(
                        "Mini-Slack binds loopback, or an explicitly isolated container network");
            }
        }

        public static Settings local() {
            return new Settings(
                    "127.0.0.1", 0, "test", false, true, UUID.randomUUID().toString());
        }
    }

    private static final System.Logger LOG = System.getLogger(MiniSlackServer.class.getName());
    private static final int MAX_BODY = 1024 * 1024;
    private final Settings settings;
    private final HttpServer server;
    private final ExecutorService executor;
    private final Semaphore capacity = new Semaphore(64);
    private final AtomicBoolean closed = new AtomicBoolean();
    private final SlackState state;
    private final Faults faults = new Faults();
    private final Evidence evidence = new Evidence();
    private final WebApi web;
    private final ScimApi scim;
    private final TestController controller;

    public MiniSlackServer(Settings settings) throws IOException {
        this(settings, Clock.systemUTC());
    }

    public MiniSlackServer(Settings settings, Clock clock) throws IOException {
        this(settings, clock, null);
    }

    public MiniSlackServer(Settings settings, Clock clock, @Nullable JsonNode initialFixture) throws IOException {
        rejectProduction(System.getenv());
        this.settings = settings;
        state = new SlackState(clock);
        web = new WebApi(state);
        scim = new ScimApi(state);
        controller = new TestController(state, faults, evidence);
        if (initialFixture != null) {
            Fixtures.seed(state, initialFixture);
        }
        server = HttpServer.create(
                new InetSocketAddress(InetAddress.getByName(settings.address()), settings.port()), 64);
        executor = Executors.newVirtualThreadPerTaskExecutor();
        server.setExecutor(executor);
        server.createContext("/", this::handle);
        server.start();
        LOG.log(
                System.Logger.Level.INFO,
                "Mini-Slack test simulator listening on port {0}",
                server.getAddress().getPort());
    }

    public static MiniSlackServer local() throws IOException {
        return new MiniSlackServer(Settings.local());
    }

    public URI baseUri() {
        return URI.create("http://" + (settings.address().equals("::1") ? "[::1]" : "127.0.0.1") + ":"
                + server.getAddress().getPort());
    }

    public String testSecret() {
        return settings.testSecret();
    }

    public Map<String, String> environment(String project, String service) {
        if (!project.matches("[A-Za-z][A-Za-z0-9_]*") || !service.matches("[A-Za-z][A-Za-z0-9_]*")) {
            throw new IllegalArgumentException("Invalid service identifier");
        }
        String prefix = "CHERRY_TEST_" + project.toUpperCase(Locale.ROOT) + "_" + service.toUpperCase(Locale.ROOT);
        return Map.of(
                prefix + "_URL",
                baseUri().toString(),
                prefix + "_HOST",
                baseUri().getHost(),
                prefix + "_PORT",
                Integer.toString(server.getAddress().getPort()),
                "SLACK_API_BASE_URL",
                baseUri() + "/api",
                "SLACK_SCIM_BASE_URL",
                baseUri() + "/scim/v2");
    }

    public void seed(JsonNode fixture) {
        synchronized (state) {
            Fixtures.seed(state, fixture);
            faults.clear();
            evidence.clear();
        }
    }

    public List<ObjectNode> requests() {
        return evidence.requests();
    }

    public void writeReport(Path reportDirectory, String packageName, String fullName, boolean passed, String reason)
            throws IOException {
        evidence.report(
                reportDirectory,
                packageName,
                fullName,
                passed,
                settings.testSecret().isEmpty() ? reason : reason.replace(settings.testSecret(), "[REDACTED]"),
                baseUri().toString());
    }

    static void rejectProduction(Map<String, String> env) {
        for (String key : List.of("APP_ENV", "ENVIRONMENT", "SPRING_PROFILES_ACTIVE", "NODE_ENV")) {
            String value = env.getOrDefault(key, "").toLowerCase(Locale.ROOT);
            for (String part : value.split("[,\\s]+", -1)) {
                if (part.equals("prod") || part.equals("production")) {
                    throw new IllegalArgumentException("Mini-Slack cannot start in production");
                }
            }
        }
    }

    private record Reply(
            int status, String body, String contentType, String error, String faultId, int retryAfter, int delayMs) {}

    private void handle(HttpExchange exchange) throws IOException {
        if (!capacity.tryAcquire()) {
            exchange.sendResponseHeaders(503, -1);
            exchange.close();
            return;
        }
        long started = System.nanoTime();
        Instant timestamp = Instant.now();
        String path = exchange.getRequestURI().getPath();
        boolean captured = path.startsWith("/api/") || path.startsWith("/scim/");
        ObjectNode input = object();
        ObjectNode query = object();
        long generation;
        synchronized (state) {
            generation = state.generation;
        }
        try {
            Reply reply;
            try {
                if (exchange.getRequestURI().toString().length() > 16384) {
                    throw new ApiException(414, "request_too_large");
                }
                query = form(exchange.getRequestURI().getRawQuery());
                input = parse(exchange);
                ObjectNode params = query.deepCopy();
                input.properties().forEach(entry -> params.set(entry.getKey(), entry.getValue()));
                synchronized (state) {
                    reply = dispatch(exchange, path, params);
                }
            } catch (ApiException exception) {
                reply = error(path, exception.status(), exception.getMessage());
            } catch (JacksonException | IllegalArgumentException exception) {
                reply = error(path, 400, "invalid_arguments");
            } catch (RuntimeException exception) {
                LOG.log(
                        System.Logger.Level.ERROR,
                        "Mini-Slack request failed: {0}",
                        exception.getClass().getName());
                reply = error(path, 500, "internal_error");
            }
            if (reply.delayMs() > 0) {
                try {
                    Thread.sleep(reply.delayMs());
                } catch (InterruptedException exception) {
                    Thread.currentThread().interrupt();
                    return;
                }
            }
            if (captured) {
                JsonNode response;
                try {
                    response = MAPPER.readTree(reply.body());
                } catch (JacksonException exception) {
                    response = object("malformed", true);
                }
                ObjectNode record = object(
                        "timestamp",
                        timestamp.toString(),
                        "method",
                        exchange.getRequestMethod(),
                        "path",
                        Evidence.scrubText(path),
                        "query",
                        Evidence.sanitize(query),
                        "body",
                        Evidence.sanitize(input),
                        "status",
                        reply.status(),
                        "error",
                        reply.error(),
                        "durationMs",
                        TimeUnit.NANOSECONDS.toMillis(System.nanoTime() - started),
                        "correlationId",
                        Evidence.scrubText(header(exchange, "X-Cherry-Test-Id")),
                        "faultId",
                        reply.faultId(),
                        "response",
                        Evidence.sanitize(response));
                synchronized (state) {
                    if (state.generation == generation) {
                        evidence.add(record);
                    }
                }
            }
            exchange.getResponseHeaders().set("Content-Type", reply.contentType());
            exchange.getResponseHeaders().set("Cache-Control", "no-store");
            exchange.getResponseHeaders().set("X-Content-Type-Options", "nosniff");
            if (reply.status() == 429) {
                exchange.getResponseHeaders().set("Retry-After", Integer.toString(reply.retryAfter()));
            }
            byte[] body = reply.body().getBytes(StandardCharsets.UTF_8);
            exchange.sendResponseHeaders(reply.status(), reply.status() == 204 ? -1 : body.length);
            if (reply.status() != 204) {
                exchange.getResponseBody().write(body);
            }
        } catch (IOException exception) {
            LOG.log(
                    System.Logger.Level.DEBUG,
                    "Mini-Slack client disconnected: {0}",
                    exception.getClass().getSimpleName());
        } finally {
            exchange.close();
            capacity.release();
        }
    }

    private Reply dispatch(HttpExchange exchange, String path, JsonNode input) {
        String verb = exchange.getRequestMethod();
        if (path.equals("/health") && verb.equals("GET")) {
            return reply(200, object("status", "ok", "simulator", "mini-slack"), "", "", 0, 0, false);
        }
        if (path.startsWith("/_test/")) {
            if (!settings.testApi()) {
                throw new ApiException(404, "route_not_found");
            }
            if (!header(exchange, "Origin").isEmpty()
                    || !MessageDigest.isEqual(
                            settings.testSecret().getBytes(StandardCharsets.UTF_8),
                            header(exchange, "X-Mini-Slack-Secret").getBytes(StandardCharsets.UTF_8))) {
                throw new ApiException(403, "test_api_forbidden");
            }
            return reply(200, controller.call(verb, path, input), "", "", 0, 0, false);
        }
        if (!path.startsWith("/api/") && !path.startsWith("/scim/v2/")) {
            throw new ApiException(404, "route_not_found");
        }
        String auth = header(exchange, "Authorization");
        String bearer = auth.regionMatches(true, 0, "Bearer ", 0, 7)
                ? auth.substring(7).trim()
                : auth.isEmpty() ? path.startsWith("/scim/") ? "" : text(input, "token", "") : "invalid-header";
        String method = path.startsWith("/api/") ? path.substring(5) : verb + " " + path;
        SlackState.Token token = state.tokens.get(bearer);
        Faults.Applied fault = faults.take(method, token == null ? "" : token.workspaceId());
        if (fault != null
                && (!fault.error().isEmpty()
                        || fault.malformed()
                        || !fault.responseBody().isMissingNode()
                        || fault.httpStatus() != 200)) {
            JsonNode body = !fault.responseBody().isMissingNode()
                    ? fault.responseBody()
                    : path.startsWith("/scim/")
                            ? ScimApi.error(fault.httpStatus(), fault.error())
                            : object("ok", false, "error", fault.error());
            Reply result = reply(
                    fault.httpStatus(),
                    body,
                    fault.error(),
                    fault.id(),
                    fault.retryAfterSeconds(),
                    fault.delayMs(),
                    path.startsWith("/scim/"));
            return fault.malformed()
                    ? new Reply(
                            result.status(),
                            "{malformed",
                            result.contentType(),
                            result.error(),
                            result.faultId(),
                            result.retryAfter(),
                            result.delayMs())
                    : result;
        }
        JsonNode body;
        int status;
        try {
            if (path.startsWith("/api/")) {
                body = web.call(method, verb, bearer, input);
                status = 200;
            } else {
                ScimApi.Result response =
                        scim.call(verb, path, bearer, input, baseUri().toString());
                body = response.body();
                status = response.status();
            }
        } catch (ApiException exception) {
            Reply failed = error(path, exception.status(), exception.getMessage());
            return new Reply(
                    failed.status(),
                    failed.body(),
                    failed.contentType(),
                    failed.error(),
                    fault == null ? "" : fault.id(),
                    0,
                    fault == null ? 0 : fault.delayMs());
        }
        if (fault != null && fault.incompletePage() && body.isObject() && body.has("response_metadata")) {
            ((ObjectNode) body).set("response_metadata", object("next_cursor", ""));
        }
        return reply(
                status,
                body,
                text(body, "error", ""),
                fault == null ? "" : fault.id(),
                0,
                fault == null ? 0 : fault.delayMs(),
                path.startsWith("/scim/"));
    }

    private static Reply reply(
            int status, JsonNode body, String error, String faultId, int retryAfter, int delayMs, boolean scim) {
        return new Reply(
                status,
                body.toString(),
                scim ? "application/scim+json" : "application/json; charset=utf-8",
                error,
                faultId,
                retryAfter,
                delayMs);
    }

    private static Reply error(String path, int status, String error) {
        if (path.startsWith("/api/")) {
            return reply(status >= 500 ? status : 200, object("ok", false, "error", error), error, "", 0, 0, false);
        }
        return reply(
                status,
                path.startsWith("/scim/") ? ScimApi.error(status, error) : object("error", error),
                error,
                "",
                0,
                0,
                path.startsWith("/scim/"));
    }

    private static String header(HttpExchange exchange, String name) {
        String value = exchange.getRequestHeaders().getFirst(name);
        return value == null ? "" : value;
    }

    private static ObjectNode parse(HttpExchange exchange) throws IOException {
        byte[] bytes = exchange.getRequestBody().readNBytes(MAX_BODY + 1);
        if (bytes.length > MAX_BODY) {
            throw new ApiException(413, "request_too_large");
        }
        if (bytes.length == 0) {
            return object();
        }
        String contentType = header(exchange, "Content-Type").toLowerCase(Locale.ROOT);
        if (contentType.startsWith("application/x-www-form-urlencoded")) {
            return form(new String(bytes, StandardCharsets.UTF_8));
        }
        if (!contentType.startsWith("application/json") && !contentType.startsWith("application/scim+json")) {
            throw new ApiException(415, "invalid_post_type");
        }
        JsonNode node = MAPPER.readTree(bytes);
        if (!node.isObject()) {
            throw new ApiException("invalid_arguments");
        }
        return (ObjectNode) node;
    }

    private static ObjectNode form(String raw) {
        ObjectNode result = object();
        if (raw == null || raw.isEmpty()) {
            return result;
        }
        for (String item : raw.split("&", -1)) {
            String[] pair = item.split("=", 2);
            result.put(
                    URLDecoder.decode(pair[0], StandardCharsets.UTF_8),
                    pair.length == 2 ? URLDecoder.decode(pair[1], StandardCharsets.UTF_8) : "");
        }
        return result;
    }

    @Override
    public void close() {
        if (!closed.compareAndSet(false, true)) {
            return;
        }
        server.stop(0);
        executor.shutdownNow();
        try {
            if (!executor.awaitTermination(5, TimeUnit.SECONDS)) {
                throw new IllegalStateException("Mini-Slack workers did not stop");
            }
        } catch (InterruptedException exception) {
            Thread.currentThread().interrupt();
            throw new IllegalStateException("Mini-Slack teardown interrupted", exception);
        }
    }
}
