package mini.slack;

import static mini.slack.Json.*;

import tools.jackson.databind.JsonNode;

final class TestController {
    private final SlackState state;
    private final Faults faults;
    private final Evidence evidence;

    TestController(SlackState state, Faults faults, Evidence evidence) {
        this.state = state;
        this.faults = faults;
        this.evidence = evidence;
    }

    JsonNode call(String verb, String path, JsonNode input) {
        String route = verb + " " + path;
        switch (route) {
            case "POST /_test/reset" -> {
                state.reset();
                faults.clear();
                evidence.clear();
                return object("reset", true);
            }
            case "POST /_test/seed" -> {
                Fixtures.seed(state, input);
                faults.clear();
                evidence.clear();
                return state.snapshot();
            }
            case "GET /_test/state" -> {
                return state.snapshot();
            }
            case "POST /_test/workspaces" -> {
                return object("id", state.createWorkspace(input).id);
            }
            case "POST /_test/tokens" -> {
                SlackState.Token token = state.createToken(input);
                return object("id", token.id(), "token", token.value());
            }
            case "POST /_test/faults" -> {
                return faults.add(input);
            }
            case "DELETE /_test/faults" -> {
                faults.clear();
                return object("cleared", true);
            }
            case "GET /_test/requests" -> {
                return array(evidence.requests());
            }
            case "DELETE /_test/requests" -> {
                evidence.clear();
                return object("cleared", true);
            }
            default -> {}
        }
        SlackState.Workspace workspace = state.workspace(required(input, "workspaceId"));
        switch (route) {
            case "POST /_test/users" -> {
                return state.createUser(workspace, input).slack(workspace.id, true);
            }
            case "POST /_test/channels" -> {
                return state.createChannel(workspace, input).slack("");
            }
            case "POST /_test/invitations" -> {
                return state.invite(workspace, input).json();
            }
            default -> {}
        }
        String[] parts = path.split("/", -1);
        if (parts.length == 4
                && parts[2].equals("workspaces")
                && verb.equals("PATCH")
                && parts[3].equals(workspace.id)) {
            workspace.plan = SlackState.plan(required(input, "plan"));
            state.event(workspace.id, "workspace.plan_changed", workspace.id);
            return object("id", workspace.id, "plan", workspace.plan.name());
        }
        if (parts.length == 4 && parts[2].equals("users") && verb.equals("PATCH")) {
            SlackState.User user = state.user(workspace, parts[3]);
            state.updateUser(workspace, user, input);
            return user.slack(workspace.id, true);
        }
        if (parts.length == 5 && verb.equals("POST")) {
            if (parts[2].equals("invitations") && (parts[4].equals("accept") || parts[4].equals("reject"))) {
                return state.resolveInvitation(workspace, parts[3], parts[4].equals("accept"))
                        .json();
            }
            if (parts[2].equals("users") && (parts[4].equals("activate") || parts[4].equals("deactivate"))) {
                SlackState.User user = state.user(workspace, parts[3]);
                state.accountActive(workspace, user, parts[4].equals("activate"));
                return user.slack(workspace.id, true);
            }
        }
        throw new ApiException(404, "route_not_found");
    }
}
